op_version_set = 1
class Linear(Module):
  __parameters__ = ["bias", "weight", ]
  training : bool
  bias : Tensor
  weight : Tensor
  __constants__ : List[str]
  def forward(self: __torch__.torch.nn.modules.linear.___torch_mangle_21.Linear,
    input: Tensor) -> Tensor:
    _0 = self.weight
    _1 = self.bias
    if torch.eq(torch.dim(input), 2):
      _2 = torch.__isnot__(_1, None)
    else:
      _2 = False
    if _2:
      bias = ops.prim.unchecked_unwrap_optional(_1)
      ret = torch.addmm(bias, input, torch.t(_0), beta=1, alpha=1)
    else:
      output = torch.matmul(input, torch.t(_0))
      if torch.__isnot__(_1, None):
        bias0 = ops.prim.unchecked_unwrap_optional(_1)
        output0 = torch.add_(output, bias0, alpha=1)
      else:
        output0 = output
      ret = output0
    return ret
