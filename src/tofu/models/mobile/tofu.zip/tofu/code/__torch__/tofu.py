op_version_set = 1
import __torch__.torch.nn.modules.conv
import __torch__.torch.nn.modules.pooling
import __torch__.torch.nn.modules.conv.___torch_mangle_3
import __torch__.torch.nn.modules.pooling.___torch_mangle_8
import __torch__.torch.nn.modules.conv.___torch_mangle_11
import __torch__.torch.nn.modules.pooling.___torch_mangle_16
import __torch__.torch.nn.modules.flatten
import __torch__.torch.nn.modules.linear
import __torch__.torch.nn.modules.linear.___torch_mangle_18
import __torch__.torch.nn.modules.linear.___torch_mangle_21
import __torch__.torch.nn.modules.conv.___torch_mangle_24
class Tofu(Module):
  __parameters__ = []
  training : bool
  batch_size : int
  epochs : int
  input_shape : Tuple[int, int]
  latent_space_dims : int
  encoder_input : __torch__.torch.nn.modules.conv.Conv2d
  encoder_input_pool : __torch__.torch.nn.modules.pooling.MaxPool2d
  encoder_h1 : __torch__.torch.nn.modules.conv.___torch_mangle_3.Conv2d
  encoder_h1_pool : __torch__.torch.nn.modules.pooling.___torch_mangle_8.MaxPool2d
  encoder_h2 : __torch__.torch.nn.modules.conv.___torch_mangle_11.Conv2d
  encoder_h2_pool : __torch__.torch.nn.modules.pooling.___torch_mangle_16.MaxPool2d
  encoder_flatten : __torch__.torch.nn.modules.flatten.Flatten
  encoder_mu : __torch__.torch.nn.modules.linear.Linear
  encoder_output : __torch__.torch.nn.modules.linear.___torch_mangle_18.Linear
  decoder_input : __torch__.torch.nn.modules.linear.___torch_mangle_21.Linear
  decoder_h1 : __torch__.torch.nn.modules.conv.ConvTranspose2d
  decoder_h2 : __torch__.torch.nn.modules.conv.___torch_mangle_24.ConvTranspose2d
  def forward(self: __torch__.tofu.Tofu,
    layer_input: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor]:
    _0 = self.encoder_input
    _1 = _0.weight
    _2 = uninitialized(Tensor)
    if torch.eq("zeros", "circular"):
      _5 = torch.floordiv(torch.add(0, 1), 2)
      _6 = torch.floordiv(0, 2)
      _7 = torch.floordiv(torch.add(0, 1), 2)
      _8 = [_5, _6, _7, torch.floordiv(0, 2)]
      _9 = uninitialized(Tensor)
      _10 = torch.eq(torch.remainder(torch.len(_8), 2), 0)
      if _10:
        pass
      else:
        ops.prim.RaiseException("Exception")
      _11 = torch.le(torch.floordiv(torch.len(_8), 2), torch.dim(layer_input))
      if _11:
        pass
      else:
        ops.prim.RaiseException("Exception")
      if torch.eq("circular", "constant"):
        _12 = torch.constant_pad_nd(layer_input, _8, 0.)
      else:
        if torch.eq(0., 0):
          pass
        else:
          ops.prim.RaiseException("Exception")
        _13 = torch.eq(torch.dim(layer_input), 3)
        if _13:
          if torch.eq(torch.len(_8), 2):
            pass
          else:
            ops.prim.RaiseException("Exception")
          _15 = torch.eq("circular", "reflect")
          if _15:
            _16 = torch.reflection_pad1d(layer_input, _8)
          else:
            _17 = torch.eq("circular", "replicate")
            if _17:
              _18 = torch.replication_pad1d(layer_input, _8)
            else:
              _19 = torch.eq("circular", "circular")
              if _19:
                _21 = torch.slice(layer_input, 0, 0, 9223372036854775807, 1)
                _22 = torch.slice(_21, 1, 0, 9223372036854775807, 1)
                _23 = torch.slice(_22, 2, 0, _8[-1], 1)
                input = torch.cat([layer_input, _23], 2)
                _24 = torch.slice(input, 0, 0, 9223372036854775807, 1)
                _25 = torch.add(_8[-1], _8[-2])
                _26 = torch.slice(_24, 1, 0, 9223372036854775807, 1)
                _27 = torch.slice(_26, 2, torch.neg(_25), torch.neg(_8[-1]), 1)
                input0 = torch.cat([_27, input], 2)
                _28 = torch.gt(torch.len(_8), 2)
                if _28:
                  _29 = torch.slice(input0, 0, 0, 9223372036854775807, 1)
                  _30 = torch.slice(_29, 1, 0, 9223372036854775807, 1)
                  _31 = torch.slice(_30, 2, 0, 9223372036854775807, 1)
                  _32 = torch.slice(_31, 3, 0, _8[-3], 1)
                  input2 = torch.cat([input0, _32], 3)
                  _33 = torch.slice(input2, 0, 0, 9223372036854775807, 1)
                  _34 = torch.slice(_33, 1, 0, 9223372036854775807, 1)
                  _35 = torch.add(_8[-3], _8[-4])
                  _36 = torch.slice(_34, 2, 0, 9223372036854775807, 1)
                  _37 = torch.slice(_36, 3, torch.neg(_35), torch.neg(_8[-3]), 1)
                  input1 = torch.cat([_37, input2], 3)
                else:
                  input1 = input0
                _38 = torch.gt(torch.len(_8), 4)
                if _38:
                  _39 = torch.slice(input1, 0, 0, 9223372036854775807, 1)
                  _40 = torch.slice(_39, 1, 0, 9223372036854775807, 1)
                  _41 = torch.slice(_40, 2, 0, 9223372036854775807, 1)
                  _42 = torch.slice(_41, 3, 0, 9223372036854775807, 1)
                  _43 = torch.slice(_42, 4, 0, _8[-5], 1)
                  input4 = torch.cat([input1, _43], 4)
                  _44 = torch.slice(input4, 0, 0, 9223372036854775807, 1)
                  _45 = torch.slice(_44, 1, 0, 9223372036854775807, 1)
                  _46 = torch.slice(_45, 2, 0, 9223372036854775807, 1)
                  _47 = torch.add(_8[-5], _8[-6])
                  _48 = torch.slice(_46, 3, 0, 9223372036854775807, 1)
                  _49 = torch.slice(_48, 4, torch.neg(_47), torch.neg(_8[-5]), 1)
                  input3 = torch.cat([_49, input4], 4)
                else:
                  input3 = input1
                _20 = input3
              else:
                ops.prim.RaiseException("Exception")
                _20 = _9
              _18 = _20
            _16 = _18
          _14 = _16
        else:
          _50 = torch.eq(torch.dim(layer_input), 4)
          if _50:
            if torch.eq(torch.len(_8), 4):
              pass
            else:
              ops.prim.RaiseException("Exception")
            _52 = torch.eq("circular", "reflect")
            if _52:
              _53 = torch.reflection_pad2d(layer_input, _8)
            else:
              _54 = torch.eq("circular", "replicate")
              if _54:
                _55 = torch.replication_pad2d(layer_input, _8)
              else:
                _56 = torch.eq("circular", "circular")
                if _56:
                  _58 = torch.slice(layer_input, 0, 0, 9223372036854775807, 1)
                  _59 = torch.slice(_58, 1, 0, 9223372036854775807, 1)
                  _60 = torch.slice(_59, 2, 0, _8[-1], 1)
                  input5 = torch.cat([layer_input, _60], 2)
                  _61 = torch.slice(input5, 0, 0, 9223372036854775807, 1)
                  _62 = torch.add(_8[-1], _8[-2])
                  _63 = torch.slice(_61, 1, 0, 9223372036854775807, 1)
                  _64 = torch.slice(_63, 2, torch.neg(_62), torch.neg(_8[-1]), 1)
                  input6 = torch.cat([_64, input5], 2)
                  _65 = torch.gt(torch.len(_8), 2)
                  if _65:
                    _66 = torch.slice(input6, 0, 0, 9223372036854775807, 1)
                    _67 = torch.slice(_66, 1, 0, 9223372036854775807, 1)
                    _68 = torch.slice(_67, 2, 0, 9223372036854775807, 1)
                    _69 = torch.slice(_68, 3, 0, _8[-3], 1)
                    input8 = torch.cat([input6, _69], 3)
                    _70 = torch.slice(input8, 0, 0, 9223372036854775807, 1)
                    _71 = torch.slice(_70, 1, 0, 9223372036854775807, 1)
                    _72 = torch.add(_8[-3], _8[-4])
                    _73 = torch.slice(_71, 2, 0, 9223372036854775807, 1)
                    _74 = torch.slice(_73, 3, torch.neg(_72), torch.neg(_8[-3]), 1)
                    input7 = torch.cat([_74, input8], 3)
                  else:
                    input7 = input6
                  _75 = torch.gt(torch.len(_8), 4)
                  if _75:
                    _76 = torch.slice(input7, 0, 0, 9223372036854775807, 1)
                    _77 = torch.slice(_76, 1, 0, 9223372036854775807, 1)
                    _78 = torch.slice(_77, 2, 0, 9223372036854775807, 1)
                    _79 = torch.slice(_78, 3, 0, 9223372036854775807, 1)
                    _80 = torch.slice(_79, 4, 0, _8[-5], 1)
                    input10 = torch.cat([input7, _80], 4)
                    _81 = torch.slice(input10, 0, 0, 9223372036854775807, 1)
                    _82 = torch.slice(_81, 1, 0, 9223372036854775807, 1)
                    _83 = torch.slice(_82, 2, 0, 9223372036854775807, 1)
                    _84 = torch.add(_8[-5], _8[-6])
                    _85 = torch.slice(_83, 3, 0, 9223372036854775807, 1)
                    _86 = torch.slice(_85, 4, torch.neg(_84), torch.neg(_8[-5]), 1)
                    input9 = torch.cat([_86, input10], 4)
                  else:
                    input9 = input7
                  _57 = input9
                else:
                  ops.prim.RaiseException("Exception")
                  _57 = _9
                _55 = _57
              _53 = _55
            _51 = _53
          else:
            _87 = torch.eq(torch.dim(layer_input), 5)
            if _87:
              _89 = torch.eq(torch.len(_8), 6)
              if _89:
                pass
              else:
                ops.prim.RaiseException("Exception")
              _90 = torch.eq("circular", "reflect")
              if _90:
                ops.prim.RaiseException("Exception")
                _91 = _9
              else:
                _92 = torch.eq("circular", "replicate")
                if _92:
                  _93 = torch.replication_pad3d(layer_input, _8)
                else:
                  _94 = torch.eq("circular", "circular")
                  if _94:
                    _96 = torch.slice(layer_input, 0, 0, 9223372036854775807, 1)
                    _97 = torch.slice(_96, 1, 0, 9223372036854775807, 1)
                    _98 = torch.slice(_97, 2, 0, _8[-1], 1)
                    input11 = torch.cat([layer_input, _98], 2)
                    _99 = torch.slice(input11, 0, 0, 9223372036854775807, 1)
                    _100 = torch.add(_8[-1], _8[-2])
                    _101 = torch.slice(_99, 1, 0, 9223372036854775807, 1)
                    _102 = torch.slice(_101, 2, torch.neg(_100), torch.neg(_8[-1]), 1)
                    input12 = torch.cat([_102, input11], 2)
                    _103 = torch.gt(torch.len(_8), 2)
                    if _103:
                      _104 = torch.slice(input12, 0, 0, 9223372036854775807, 1)
                      _105 = torch.slice(_104, 1, 0, 9223372036854775807, 1)
                      _106 = torch.slice(_105, 2, 0, 9223372036854775807, 1)
                      _107 = torch.slice(_106, 3, 0, _8[-3], 1)
                      input14 = torch.cat([input12, _107], 3)
                      _108 = torch.slice(input14, 0, 0, 9223372036854775807, 1)
                      _109 = torch.slice(_108, 1, 0, 9223372036854775807, 1)
                      _110 = torch.add(_8[-3], _8[-4])
                      _111 = torch.slice(_109, 2, 0, 9223372036854775807, 1)
                      _112 = torch.slice(_111, 3, torch.neg(_110), torch.neg(_8[-3]), 1)
                      input13 = torch.cat([_112, input14], 3)
                    else:
                      input13 = input12
                    _113 = torch.gt(torch.len(_8), 4)
                    if _113:
                      _114 = torch.slice(input13, 0, 0, 9223372036854775807, 1)
                      _115 = torch.slice(_114, 1, 0, 9223372036854775807, 1)
                      _116 = torch.slice(_115, 2, 0, 9223372036854775807, 1)
                      _117 = torch.slice(_116, 3, 0, 9223372036854775807, 1)
                      _118 = torch.slice(_117, 4, 0, _8[-5], 1)
                      input16 = torch.cat([input13, _118], 4)
                      _119 = torch.slice(input16, 0, 0, 9223372036854775807, 1)
                      _120 = torch.slice(_119, 1, 0, 9223372036854775807, 1)
                      _121 = torch.slice(_120, 2, 0, 9223372036854775807, 1)
                      _122 = torch.add(_8[-5], _8[-6])
                      _123 = torch.slice(_121, 3, 0, 9223372036854775807, 1)
                      _124 = torch.slice(_123, 4, torch.neg(_122), torch.neg(_8[-5]), 1)
                      input15 = torch.cat([_124, input16], 4)
                    else:
                      input15 = input13
                    _95 = input15
                  else:
                    ops.prim.RaiseException("Exception")
                    _95 = _9
                  _93 = _95
                _91 = _93
              _88 = _91
            else:
              ops.prim.RaiseException("Exception")
              _88 = _9
            _51 = _88
          _14 = _51
        _12 = _14
      _125 = _0.bias
      _126 = [0, 0]
      _3, _4 = True, torch.conv2d(_12, _1, _125, [1, 1], _126, [1, 1], 1)
    else:
      _3, _4 = False, _2
    if _3:
      _127 = _4
    else:
      _127 = torch.conv2d(layer_input, _1, _0.bias, [1, 1], [0, 0], [1, 1], 1)
    if False:
      layer_input0 = torch.relu_(_127)
    else:
      layer_input0 = torch.relu(_127)
    _128 = [2, 2]
    _129 = [2, 2]
    _130 = [0, 0]
    _131 = [1, 1]
    if torch.__is__(_129, None):
      stride = annotate(List[int], [])
    else:
      stride = ops.prim.unchecked_unwrap_optional(_129)
    layer_input1 = torch.max_pool2d(layer_input0, _128, stride, _130, _131, False)
    _132 = self.encoder_h1
    _133 = _132.weight
    _134 = uninitialized(Tensor)
    if torch.eq("zeros", "circular"):
      _137 = torch.floordiv(torch.add(0, 1), 2)
      _138 = torch.floordiv(0, 2)
      _139 = torch.floordiv(torch.add(0, 1), 2)
      _140 = [_137, _138, _139, torch.floordiv(0, 2)]
      _141 = uninitialized(Tensor)
      _142 = torch.remainder(torch.len(_140), 2)
      if torch.eq(_142, 0):
        pass
      else:
        ops.prim.RaiseException("Exception")
      _143 = torch.floordiv(torch.len(_140), 2)
      _144 = torch.le(_143, torch.dim(layer_input1))
      if _144:
        pass
      else:
        ops.prim.RaiseException("Exception")
      if torch.eq("circular", "constant"):
        _145 = torch.constant_pad_nd(layer_input1, _140, 0.)
      else:
        if torch.eq(0., 0):
          pass
        else:
          ops.prim.RaiseException("Exception")
        _146 = torch.eq(torch.dim(layer_input1), 3)
        if _146:
          if torch.eq(torch.len(_140), 2):
            pass
          else:
            ops.prim.RaiseException("Exception")
          _148 = torch.eq("circular", "reflect")
          if _148:
            _149 = torch.reflection_pad1d(layer_input1, _140)
          else:
            _150 = torch.eq("circular", "replicate")
            if _150:
              _151 = torch.replication_pad1d(layer_input1, _140)
            else:
              _152 = torch.eq("circular", "circular")
              if _152:
                _154 = torch.slice(layer_input1, 0, 0, 9223372036854775807, 1)
                _155 = torch.slice(_154, 1, 0, 9223372036854775807, 1)
                _156 = torch.slice(_155, 2, 0, _140[-1], 1)
                input17 = torch.cat([layer_input1, _156], 2)
                _157 = torch.slice(input17, 0, 0, 9223372036854775807, 1)
                _158 = torch.add(_140[-1], _140[-2])
                _159 = torch.slice(_157, 1, 0, 9223372036854775807, 1)
                _160 = torch.slice(_159, 2, torch.neg(_158), torch.neg(_140[-1]), 1)
                input18 = torch.cat([_160, input17], 2)
                _161 = torch.gt(torch.len(_140), 2)
                if _161:
                  _162 = torch.slice(input18, 0, 0, 9223372036854775807, 1)
                  _163 = torch.slice(_162, 1, 0, 9223372036854775807, 1)
                  _164 = torch.slice(_163, 2, 0, 9223372036854775807, 1)
                  _165 = torch.slice(_164, 3, 0, _140[-3], 1)
                  input20 = torch.cat([input18, _165], 3)
                  _166 = torch.slice(input20, 0, 0, 9223372036854775807, 1)
                  _167 = torch.slice(_166, 1, 0, 9223372036854775807, 1)
                  _168 = torch.add(_140[-3], _140[-4])
                  _169 = torch.slice(_167, 2, 0, 9223372036854775807, 1)
                  _170 = torch.slice(_169, 3, torch.neg(_168), torch.neg(_140[-3]), 1)
                  input19 = torch.cat([_170, input20], 3)
                else:
                  input19 = input18
                _171 = torch.gt(torch.len(_140), 4)
                if _171:
                  _172 = torch.slice(input19, 0, 0, 9223372036854775807, 1)
                  _173 = torch.slice(_172, 1, 0, 9223372036854775807, 1)
                  _174 = torch.slice(_173, 2, 0, 9223372036854775807, 1)
                  _175 = torch.slice(_174, 3, 0, 9223372036854775807, 1)
                  _176 = torch.slice(_175, 4, 0, _140[-5], 1)
                  input22 = torch.cat([input19, _176], 4)
                  _177 = torch.slice(input22, 0, 0, 9223372036854775807, 1)
                  _178 = torch.slice(_177, 1, 0, 9223372036854775807, 1)
                  _179 = torch.slice(_178, 2, 0, 9223372036854775807, 1)
                  _180 = torch.add(_140[-5], _140[-6])
                  _181 = torch.slice(_179, 3, 0, 9223372036854775807, 1)
                  _182 = torch.slice(_181, 4, torch.neg(_180), torch.neg(_140[-5]), 1)
                  input21 = torch.cat([_182, input22], 4)
                else:
                  input21 = input19
                _153 = input21
              else:
                ops.prim.RaiseException("Exception")
                _153 = _141
              _151 = _153
            _149 = _151
          _147 = _149
        else:
          _183 = torch.eq(torch.dim(layer_input1), 4)
          if _183:
            _185 = torch.eq(torch.len(_140), 4)
            if _185:
              pass
            else:
              ops.prim.RaiseException("Exception")
            _186 = torch.eq("circular", "reflect")
            if _186:
              _187 = torch.reflection_pad2d(layer_input1, _140)
            else:
              _188 = torch.eq("circular", "replicate")
              if _188:
                _189 = torch.replication_pad2d(layer_input1, _140)
              else:
                _190 = torch.eq("circular", "circular")
                if _190:
                  _192 = torch.slice(layer_input1, 0, 0, 9223372036854775807, 1)
                  _193 = torch.slice(_192, 1, 0, 9223372036854775807, 1)
                  _194 = torch.slice(_193, 2, 0, _140[-1], 1)
                  input23 = torch.cat([layer_input1, _194], 2)
                  _195 = torch.slice(input23, 0, 0, 9223372036854775807, 1)
                  _196 = torch.add(_140[-1], _140[-2])
                  _197 = torch.slice(_195, 1, 0, 9223372036854775807, 1)
                  _198 = torch.slice(_197, 2, torch.neg(_196), torch.neg(_140[-1]), 1)
                  input24 = torch.cat([_198, input23], 2)
                  _199 = torch.gt(torch.len(_140), 2)
                  if _199:
                    _200 = torch.slice(input24, 0, 0, 9223372036854775807, 1)
                    _201 = torch.slice(_200, 1, 0, 9223372036854775807, 1)
                    _202 = torch.slice(_201, 2, 0, 9223372036854775807, 1)
                    _203 = torch.slice(_202, 3, 0, _140[-3], 1)
                    input26 = torch.cat([input24, _203], 3)
                    _204 = torch.slice(input26, 0, 0, 9223372036854775807, 1)
                    _205 = torch.slice(_204, 1, 0, 9223372036854775807, 1)
                    _206 = torch.add(_140[-3], _140[-4])
                    _207 = torch.slice(_205, 2, 0, 9223372036854775807, 1)
                    _208 = torch.slice(_207, 3, torch.neg(_206), torch.neg(_140[-3]), 1)
                    input25 = torch.cat([_208, input26], 3)
                  else:
                    input25 = input24
                  _209 = torch.gt(torch.len(_140), 4)
                  if _209:
                    _210 = torch.slice(input25, 0, 0, 9223372036854775807, 1)
                    _211 = torch.slice(_210, 1, 0, 9223372036854775807, 1)
                    _212 = torch.slice(_211, 2, 0, 9223372036854775807, 1)
                    _213 = torch.slice(_212, 3, 0, 9223372036854775807, 1)
                    _214 = torch.slice(_213, 4, 0, _140[-5], 1)
                    input28 = torch.cat([input25, _214], 4)
                    _215 = torch.slice(input28, 0, 0, 9223372036854775807, 1)
                    _216 = torch.slice(_215, 1, 0, 9223372036854775807, 1)
                    _217 = torch.slice(_216, 2, 0, 9223372036854775807, 1)
                    _218 = torch.add(_140[-5], _140[-6])
                    _219 = torch.slice(_217, 3, 0, 9223372036854775807, 1)
                    _220 = torch.slice(_219, 4, torch.neg(_218), torch.neg(_140[-5]), 1)
                    input27 = torch.cat([_220, input28], 4)
                  else:
                    input27 = input25
                  _191 = input27
                else:
                  ops.prim.RaiseException("Exception")
                  _191 = _141
                _189 = _191
              _187 = _189
            _184 = _187
          else:
            _221 = torch.eq(torch.dim(layer_input1), 5)
            if _221:
              _223 = torch.eq(torch.len(_140), 6)
              if _223:
                pass
              else:
                ops.prim.RaiseException("Exception")
              _224 = torch.eq("circular", "reflect")
              if _224:
                ops.prim.RaiseException("Exception")
                _225 = _141
              else:
                _226 = torch.eq("circular", "replicate")
                if _226:
                  _227 = torch.replication_pad3d(layer_input1, _140)
                else:
                  _228 = torch.eq("circular", "circular")
                  if _228:
                    _230 = torch.slice(layer_input1, 0, 0, 9223372036854775807, 1)
                    _231 = torch.slice(_230, 1, 0, 9223372036854775807, 1)
                    _232 = torch.slice(_231, 2, 0, _140[-1], 1)
                    _233 = [layer_input1, _232]
                    input29 = torch.cat(_233, 2)
                    _234 = torch.slice(input29, 0, 0, 9223372036854775807, 1)
                    _235 = torch.add(_140[-1], _140[-2])
                    _236 = torch.slice(_234, 1, 0, 9223372036854775807, 1)
                    _237 = torch.slice(_236, 2, torch.neg(_235), torch.neg(_140[-1]), 1)
                    input30 = torch.cat([_237, input29], 2)
                    _238 = torch.gt(torch.len(_140), 2)
                    if _238:
                      _239 = torch.slice(input30, 0, 0, 9223372036854775807, 1)
                      _240 = torch.slice(_239, 1, 0, 9223372036854775807, 1)
                      _241 = torch.slice(_240, 2, 0, 9223372036854775807, 1)
                      _242 = torch.slice(_241, 3, 0, _140[-3], 1)
                      input32 = torch.cat([input30, _242], 3)
                      _243 = torch.slice(input32, 0, 0, 9223372036854775807, 1)
                      _244 = torch.slice(_243, 1, 0, 9223372036854775807, 1)
                      _245 = torch.add(_140[-3], _140[-4])
                      _246 = torch.slice(_244, 2, 0, 9223372036854775807, 1)
                      _247 = torch.neg(_245)
                      _248 = torch.neg(_140[-3])
                      _249 = torch.slice(_246, 3, _247, _248, 1)
                      input31 = torch.cat([_249, input32], 3)
                    else:
                      input31 = input30
                    _250 = torch.gt(torch.len(_140), 4)
                    if _250:
                      _251 = torch.slice(input31, 0, 0, 9223372036854775807, 1)
                      _252 = torch.slice(_251, 1, 0, 9223372036854775807, 1)
                      _253 = torch.slice(_252, 2, 0, 9223372036854775807, 1)
                      _254 = torch.slice(_253, 3, 0, 9223372036854775807, 1)
                      _255 = torch.slice(_254, 4, 0, _140[-5], 1)
                      input34 = torch.cat([input31, _255], 4)
                      _256 = torch.slice(input34, 0, 0, 9223372036854775807, 1)
                      _257 = torch.slice(_256, 1, 0, 9223372036854775807, 1)
                      _258 = torch.slice(_257, 2, 0, 9223372036854775807, 1)
                      _259 = torch.add(_140[-5], _140[-6])
                      _260 = torch.slice(_258, 3, 0, 9223372036854775807, 1)
                      _261 = torch.neg(_259)
                      _262 = torch.neg(_140[-5])
                      _263 = torch.slice(_260, 4, _261, _262, 1)
                      input33 = torch.cat([_263, input34], 4)
                    else:
                      input33 = input31
                    _229 = input33
                  else:
                    ops.prim.RaiseException("Exception")
                    _229 = _141
                  _227 = _229
                _225 = _227
              _222 = _225
            else:
              ops.prim.RaiseException("Exception")
              _222 = _141
            _184 = _222
          _147 = _184
        _145 = _147
      _264 = _132.bias
      _265 = [0, 0]
      _135, _136 = True, torch.conv2d(_145, _133, _264, [1, 1], _265, [1, 1], 1)
    else:
      _135, _136 = False, _134
    if _135:
      _266 = _136
    else:
      _266 = torch.conv2d(layer_input1, _133, _132.bias, [1, 1], [0, 0], [1, 1], 1)
    if False:
      layer_input2 = torch.relu_(_266)
    else:
      layer_input2 = torch.relu(_266)
    _267 = [2, 2]
    _268 = [2, 2]
    _269 = [0, 0]
    _270 = [1, 1]
    if torch.__is__(_268, None):
      stride0 = annotate(List[int], [])
    else:
      stride0 = ops.prim.unchecked_unwrap_optional(_268)
    layer_input3 = torch.max_pool2d(layer_input2, _267, stride0, _269, _270, False)
    _271 = self.encoder_h2
    _272 = _271.weight
    _273 = uninitialized(Tensor)
    if torch.eq("zeros", "circular"):
      _276 = torch.floordiv(torch.add(0, 1), 2)
      _277 = torch.floordiv(0, 2)
      _278 = torch.floordiv(torch.add(0, 1), 2)
      _279 = [_276, _277, _278, torch.floordiv(0, 2)]
      _280 = uninitialized(Tensor)
      _281 = torch.remainder(torch.len(_279), 2)
      if torch.eq(_281, 0):
        pass
      else:
        ops.prim.RaiseException("Exception")
      _282 = torch.floordiv(torch.len(_279), 2)
      _283 = torch.le(_282, torch.dim(layer_input3))
      if _283:
        pass
      else:
        ops.prim.RaiseException("Exception")
      if torch.eq("circular", "constant"):
        _284 = torch.constant_pad_nd(layer_input3, _279, 0.)
      else:
        if torch.eq(0., 0):
          pass
        else:
          ops.prim.RaiseException("Exception")
        _285 = torch.eq(torch.dim(layer_input3), 3)
        if _285:
          if torch.eq(torch.len(_279), 2):
            pass
          else:
            ops.prim.RaiseException("Exception")
          _287 = torch.eq("circular", "reflect")
          if _287:
            _288 = torch.reflection_pad1d(layer_input3, _279)
          else:
            _289 = torch.eq("circular", "replicate")
            if _289:
              _290 = torch.replication_pad1d(layer_input3, _279)
            else:
              _291 = torch.eq("circular", "circular")
              if _291:
                _293 = torch.slice(layer_input3, 0, 0, 9223372036854775807, 1)
                _294 = torch.slice(_293, 1, 0, 9223372036854775807, 1)
                _295 = torch.slice(_294, 2, 0, _279[-1], 1)
                input35 = torch.cat([layer_input3, _295], 2)
                _296 = torch.slice(input35, 0, 0, 9223372036854775807, 1)
                _297 = torch.add(_279[-1], _279[-2])
                _298 = torch.slice(_296, 1, 0, 9223372036854775807, 1)
                _299 = torch.slice(_298, 2, torch.neg(_297), torch.neg(_279[-1]), 1)
                input36 = torch.cat([_299, input35], 2)
                _300 = torch.gt(torch.len(_279), 2)
                if _300:
                  _301 = torch.slice(input36, 0, 0, 9223372036854775807, 1)
                  _302 = torch.slice(_301, 1, 0, 9223372036854775807, 1)
                  _303 = torch.slice(_302, 2, 0, 9223372036854775807, 1)
                  _304 = torch.slice(_303, 3, 0, _279[-3], 1)
                  input38 = torch.cat([input36, _304], 3)
                  _305 = torch.slice(input38, 0, 0, 9223372036854775807, 1)
                  _306 = torch.slice(_305, 1, 0, 9223372036854775807, 1)
                  _307 = torch.add(_279[-3], _279[-4])
                  _308 = torch.slice(_306, 2, 0, 9223372036854775807, 1)
                  _309 = torch.slice(_308, 3, torch.neg(_307), torch.neg(_279[-3]), 1)
                  input37 = torch.cat([_309, input38], 3)
                else:
                  input37 = input36
                _310 = torch.gt(torch.len(_279), 4)
                if _310:
                  _311 = torch.slice(input37, 0, 0, 9223372036854775807, 1)
                  _312 = torch.slice(_311, 1, 0, 9223372036854775807, 1)
                  _313 = torch.slice(_312, 2, 0, 9223372036854775807, 1)
                  _314 = torch.slice(_313, 3, 0, 9223372036854775807, 1)
                  _315 = torch.slice(_314, 4, 0, _279[-5], 1)
                  input40 = torch.cat([input37, _315], 4)
                  _316 = torch.slice(input40, 0, 0, 9223372036854775807, 1)
                  _317 = torch.slice(_316, 1, 0, 9223372036854775807, 1)
                  _318 = torch.slice(_317, 2, 0, 9223372036854775807, 1)
                  _319 = torch.add(_279[-5], _279[-6])
                  _320 = torch.slice(_318, 3, 0, 9223372036854775807, 1)
                  _321 = torch.slice(_320, 4, torch.neg(_319), torch.neg(_279[-5]), 1)
                  input39 = torch.cat([_321, input40], 4)
                else:
                  input39 = input37
                _292 = input39
              else:
                ops.prim.RaiseException("Exception")
                _292 = _280
              _290 = _292
            _288 = _290
          _286 = _288
        else:
          _322 = torch.eq(torch.dim(layer_input3), 4)
          if _322:
            _324 = torch.eq(torch.len(_279), 4)
            if _324:
              pass
            else:
              ops.prim.RaiseException("Exception")
            _325 = torch.eq("circular", "reflect")
            if _325:
              _326 = torch.reflection_pad2d(layer_input3, _279)
            else:
              _327 = torch.eq("circular", "replicate")
              if _327:
                _328 = torch.replication_pad2d(layer_input3, _279)
              else:
                _329 = torch.eq("circular", "circular")
                if _329:
                  _331 = torch.slice(layer_input3, 0, 0, 9223372036854775807, 1)
                  _332 = torch.slice(_331, 1, 0, 9223372036854775807, 1)
                  _333 = torch.slice(_332, 2, 0, _279[-1], 1)
                  input41 = torch.cat([layer_input3, _333], 2)
                  _334 = torch.slice(input41, 0, 0, 9223372036854775807, 1)
                  _335 = torch.add(_279[-1], _279[-2])
                  _336 = torch.slice(_334, 1, 0, 9223372036854775807, 1)
                  _337 = torch.slice(_336, 2, torch.neg(_335), torch.neg(_279[-1]), 1)
                  input42 = torch.cat([_337, input41], 2)
                  _338 = torch.gt(torch.len(_279), 2)
                  if _338:
                    _339 = torch.slice(input42, 0, 0, 9223372036854775807, 1)
                    _340 = torch.slice(_339, 1, 0, 9223372036854775807, 1)
                    _341 = torch.slice(_340, 2, 0, 9223372036854775807, 1)
                    _342 = torch.slice(_341, 3, 0, _279[-3], 1)
                    input44 = torch.cat([input42, _342], 3)
                    _343 = torch.slice(input44, 0, 0, 9223372036854775807, 1)
                    _344 = torch.slice(_343, 1, 0, 9223372036854775807, 1)
                    _345 = torch.add(_279[-3], _279[-4])
                    _346 = torch.slice(_344, 2, 0, 9223372036854775807, 1)
                    _347 = torch.slice(_346, 3, torch.neg(_345), torch.neg(_279[-3]), 1)
                    input43 = torch.cat([_347, input44], 3)
                  else:
                    input43 = input42
                  _348 = torch.gt(torch.len(_279), 4)
                  if _348:
                    _349 = torch.slice(input43, 0, 0, 9223372036854775807, 1)
                    _350 = torch.slice(_349, 1, 0, 9223372036854775807, 1)
                    _351 = torch.slice(_350, 2, 0, 9223372036854775807, 1)
                    _352 = torch.slice(_351, 3, 0, 9223372036854775807, 1)
                    _353 = torch.slice(_352, 4, 0, _279[-5], 1)
                    input46 = torch.cat([input43, _353], 4)
                    _354 = torch.slice(input46, 0, 0, 9223372036854775807, 1)
                    _355 = torch.slice(_354, 1, 0, 9223372036854775807, 1)
                    _356 = torch.slice(_355, 2, 0, 9223372036854775807, 1)
                    _357 = torch.add(_279[-5], _279[-6])
                    _358 = torch.slice(_356, 3, 0, 9223372036854775807, 1)
                    _359 = torch.slice(_358, 4, torch.neg(_357), torch.neg(_279[-5]), 1)
                    input45 = torch.cat([_359, input46], 4)
                  else:
                    input45 = input43
                  _330 = input45
                else:
                  ops.prim.RaiseException("Exception")
                  _330 = _280
                _328 = _330
              _326 = _328
            _323 = _326
          else:
            _360 = torch.eq(torch.dim(layer_input3), 5)
            if _360:
              _362 = torch.eq(torch.len(_279), 6)
              if _362:
                pass
              else:
                ops.prim.RaiseException("Exception")
              _363 = torch.eq("circular", "reflect")
              if _363:
                ops.prim.RaiseException("Exception")
                _364 = _280
              else:
                _365 = torch.eq("circular", "replicate")
                if _365:
                  _366 = torch.replication_pad3d(layer_input3, _279)
                else:
                  _367 = torch.eq("circular", "circular")
                  if _367:
                    _369 = torch.slice(layer_input3, 0, 0, 9223372036854775807, 1)
                    _370 = torch.slice(_369, 1, 0, 9223372036854775807, 1)
                    _371 = torch.slice(_370, 2, 0, _279[-1], 1)
                    _372 = [layer_input3, _371]
                    input47 = torch.cat(_372, 2)
                    _373 = torch.slice(input47, 0, 0, 9223372036854775807, 1)
                    _374 = torch.add(_279[-1], _279[-2])
                    _375 = torch.slice(_373, 1, 0, 9223372036854775807, 1)
                    _376 = torch.slice(_375, 2, torch.neg(_374), torch.neg(_279[-1]), 1)
                    input48 = torch.cat([_376, input47], 2)
                    _377 = torch.gt(torch.len(_279), 2)
                    if _377:
                      _378 = torch.slice(input48, 0, 0, 9223372036854775807, 1)
                      _379 = torch.slice(_378, 1, 0, 9223372036854775807, 1)
                      _380 = torch.slice(_379, 2, 0, 9223372036854775807, 1)
                      _381 = torch.slice(_380, 3, 0, _279[-3], 1)
                      input50 = torch.cat([input48, _381], 3)
                      _382 = torch.slice(input50, 0, 0, 9223372036854775807, 1)
                      _383 = torch.slice(_382, 1, 0, 9223372036854775807, 1)
                      _384 = torch.add(_279[-3], _279[-4])
                      _385 = torch.slice(_383, 2, 0, 9223372036854775807, 1)
                      _386 = torch.neg(_384)
                      _387 = torch.neg(_279[-3])
                      _388 = torch.slice(_385, 3, _386, _387, 1)
                      input49 = torch.cat([_388, input50], 3)
                    else:
                      input49 = input48
                    _389 = torch.gt(torch.len(_279), 4)
                    if _389:
                      _390 = torch.slice(input49, 0, 0, 9223372036854775807, 1)
                      _391 = torch.slice(_390, 1, 0, 9223372036854775807, 1)
                      _392 = torch.slice(_391, 2, 0, 9223372036854775807, 1)
                      _393 = torch.slice(_392, 3, 0, 9223372036854775807, 1)
                      _394 = torch.slice(_393, 4, 0, _279[-5], 1)
                      input52 = torch.cat([input49, _394], 4)
                      _395 = torch.slice(input52, 0, 0, 9223372036854775807, 1)
                      _396 = torch.slice(_395, 1, 0, 9223372036854775807, 1)
                      _397 = torch.slice(_396, 2, 0, 9223372036854775807, 1)
                      _398 = torch.add(_279[-5], _279[-6])
                      _399 = torch.slice(_397, 3, 0, 9223372036854775807, 1)
                      _400 = torch.neg(_398)
                      _401 = torch.neg(_279[-5])
                      _402 = torch.slice(_399, 4, _400, _401, 1)
                      input51 = torch.cat([_402, input52], 4)
                    else:
                      input51 = input49
                    _368 = input51
                  else:
                    ops.prim.RaiseException("Exception")
                    _368 = _280
                  _366 = _368
                _364 = _366
              _361 = _364
            else:
              ops.prim.RaiseException("Exception")
              _361 = _280
            _323 = _361
          _286 = _323
        _284 = _286
      _403 = _271.bias
      _404 = [0, 0]
      _274, _275 = True, torch.conv2d(_284, _272, _403, [1, 1], _404, [1, 1], 1)
    else:
      _274, _275 = False, _273
    if _274:
      _405 = _275
    else:
      _405 = torch.conv2d(layer_input3, _272, _271.bias, [1, 1], [0, 0], [1, 1], 1)
    if False:
      layer_input4 = torch.relu_(_405)
    else:
      layer_input4 = torch.relu(_405)
    _406 = [2, 2]
    _407 = [2, 2]
    _408 = [0, 0]
    _409 = [1, 1]
    if torch.__is__(_407, None):
      stride1 = annotate(List[int], [])
    else:
      stride1 = ops.prim.unchecked_unwrap_optional(_407)
    layer_input5 = torch.max_pool2d(layer_input4, _406, stride1, _408, _409, False)
    layer_input6 = torch.flatten(layer_input5, 1, -1)
    _410 = self.encoder_mu
    _411 = _410.weight
    _412 = _410.bias
    _413 = torch.eq(torch.dim(layer_input6), 2)
    if _413:
      _414 = torch.__isnot__(_412, None)
    else:
      _414 = False
    if _414:
      bias = ops.prim.unchecked_unwrap_optional(_412)
      gaussian_param_mu = torch.addmm(bias, layer_input6, torch.t(_411), beta=1, alpha=1)
    else:
      output = torch.matmul(layer_input6, torch.t(_411))
      if torch.__isnot__(_412, None):
        bias0 = ops.prim.unchecked_unwrap_optional(_412)
        output0 = torch.add_(output, bias0, alpha=1)
      else:
        output0 = output
      gaussian_param_mu = output0
    _415 = self.encoder_output
    _416 = _415.weight
    _417 = _415.bias
    _418 = torch.eq(torch.dim(gaussian_param_mu), 2)
    if _418:
      _419 = torch.__isnot__(_417, None)
    else:
      _419 = False
    if _419:
      bias1 = ops.prim.unchecked_unwrap_optional(_417)
      gaussian_param_log_sigma = torch.addmm(bias1, gaussian_param_mu, torch.t(_416), beta=1, alpha=1)
    else:
      output1 = torch.matmul(gaussian_param_mu, torch.t(_416))
      if torch.__isnot__(_417, None):
        bias2 = ops.prim.unchecked_unwrap_optional(_417)
        output2 = torch.add_(output1, bias2, alpha=1)
      else:
        output2 = output1
      gaussian_param_log_sigma = output2
    _420 = torch.div(gaussian_param_log_sigma, 2)
    std = torch.exp(_420)
    eps = torch.randn_like(std)
    z_encoded_rep = torch.add(gaussian_param_mu, torch.mul(std, eps), alpha=1)
    _421 = self.decoder_input
    _422 = _421.weight
    _423 = _421.bias
    _424 = torch.eq(torch.dim(z_encoded_rep), 2)
    if _424:
      _425 = torch.__isnot__(_423, None)
    else:
      _425 = False
    if _425:
      bias3 = ops.prim.unchecked_unwrap_optional(_423)
      ret = torch.addmm(bias3, z_encoded_rep, torch.t(_422), beta=1, alpha=1)
    else:
      output3 = torch.matmul(z_encoded_rep, torch.t(_422))
      if torch.__isnot__(_423, None):
        bias4 = ops.prim.unchecked_unwrap_optional(_423)
        output4 = torch.add_(output3, bias4, alpha=1)
      else:
        output4 = output3
      ret = output4
    if False:
      layer_input7 = torch.relu_(ret)
    else:
      layer_input7 = torch.relu(ret)
    _426 = int(torch.div((self.input_shape)[0], 4))
    _427 = int(torch.div((self.input_shape)[1], 4))
    _428 = [(torch.size(layer_input7))[0], 32, torch.sub(_426, 1), torch.sub(_427, 1)]
    layer_input8 = torch.view(layer_input7, _428)
    _429 = self.decoder_h1
    if torch.ne("zeros", "zeros"):
      ops.prim.RaiseException("Exception")
    else:
      pass
    _430 = [2, 2]
    _431 = [0, 0]
    _432 = [3, 3]
    if torch.__is__(None, None):
      output_padding = [0, 0]
    else:
      output_size = ops.prim.unchecked_unwrap_optional(annotate(Optional[List[int]], None))
      k = torch.sub(torch.dim(layer_input8), 2)
      _433 = torch.eq(torch.len(output_size), torch.add(k, 2))
      if _433:
        output_size0 = torch.slice(output_size, 2, 9223372036854775807, 1)
      else:
        output_size0 = output_size
      _434 = torch.ne(torch.len(output_size0), k)
      if _434:
        ops.prim.RaiseException("Exception")
      else:
        pass
      min_sizes = annotate(List[int], [])
      max_sizes = annotate(List[int], [])
      for d in range(k):
        _435 = torch.size(layer_input8, torch.add(d, 2))
        _436 = torch.mul(torch.sub(_435, 1), _430[d])
        _437 = torch.sub(_436, torch.mul(2, _431[d]))
        dim_size = torch.add(_437, _432[d])
        _438 = torch.append(min_sizes, dim_size)
        _439 = torch.add(min_sizes[d], _430[d])
        _440 = torch.append(max_sizes, torch.sub(_439, 1))
      for i in range(torch.len(output_size0)):
        size = output_size0[i]
        min_size = min_sizes[i]
        max_size = max_sizes[i]
        if torch.lt(size, min_size):
          _441 = True
        else:
          _441 = torch.gt(size, max_size)
        if _441:
          ops.prim.RaiseException("Exception")
        else:
          pass
      res = annotate(List[int], [])
      for d0 in range(k):
        _442 = torch.sub(output_size0[d0], min_sizes[d0])
        _443 = torch.append(res, _442)
      output_padding = res
    _444 = torch.conv_transpose2d(layer_input8, _429.weight, _429.bias, [2, 2], [0, 0], output_padding, 1, [1, 1])
    if False:
      layer_input9 = torch.relu_(_444)
    else:
      layer_input9 = torch.relu(_444)
    _445 = self.decoder_h2
    if torch.ne("zeros", "zeros"):
      ops.prim.RaiseException("Exception")
    else:
      pass
    _446 = [2, 2]
    _447 = [0, 0]
    _448 = [3, 3]
    if torch.__is__(None, None):
      output_padding0 = [1, 1]
    else:
      output_size1 = ops.prim.unchecked_unwrap_optional(annotate(Optional[List[int]], None))
      k0 = torch.sub(torch.dim(layer_input9), 2)
      _449 = torch.eq(torch.len(output_size1), torch.add(k0, 2))
      if _449:
        output_size2 = torch.slice(output_size1, 2, 9223372036854775807, 1)
      else:
        output_size2 = output_size1
      _450 = torch.ne(torch.len(output_size2), k0)
      if _450:
        ops.prim.RaiseException("Exception")
      else:
        pass
      min_sizes0 = annotate(List[int], [])
      max_sizes0 = annotate(List[int], [])
      for d1 in range(k0):
        _451 = torch.size(layer_input9, torch.add(d1, 2))
        _452 = torch.mul(torch.sub(_451, 1), _446[d1])
        _453 = torch.sub(_452, torch.mul(2, _447[d1]))
        dim_size0 = torch.add(_453, _448[d1])
        _454 = torch.append(min_sizes0, dim_size0)
        _455 = torch.add(min_sizes0[d1], _446[d1])
        _456 = torch.append(max_sizes0, torch.sub(_455, 1))
      for i0 in range(torch.len(output_size2)):
        size0 = output_size2[i0]
        min_size0 = min_sizes0[i0]
        max_size0 = max_sizes0[i0]
        if torch.lt(size0, min_size0):
          _457 = True
        else:
          _457 = torch.gt(size0, max_size0)
        if _457:
          ops.prim.RaiseException("Exception")
        else:
          pass
      res0 = annotate(List[int], [])
      for d2 in range(k0):
        _458 = torch.sub(output_size2[d2], min_sizes0[d2])
        _459 = torch.append(res0, _458)
      output_padding0 = res0
    _460 = torch.conv_transpose2d(layer_input9, _445.weight, _445.bias, [2, 2], [0, 0], output_padding0, 1, [1, 1])
    decoding = torch.sigmoid(_460)
    _461 = (decoding, gaussian_param_mu, gaussian_param_log_sigma, z_encoded_rep)
    return _461
  def encode(self: __torch__.tofu.Tofu,
    layer_input: Tensor) -> Tuple[Tensor, Tensor]:
    _462 = self.encoder_input
    _463 = _462.weight
    _464 = uninitialized(Tensor)
    if torch.eq("zeros", "circular"):
      _467 = torch.floordiv(torch.add(0, 1), 2)
      _468 = torch.floordiv(0, 2)
      _469 = torch.floordiv(torch.add(0, 1), 2)
      _470 = [_467, _468, _469, torch.floordiv(0, 2)]
      _471 = uninitialized(Tensor)
      _472 = torch.remainder(torch.len(_470), 2)
      if torch.eq(_472, 0):
        pass
      else:
        ops.prim.RaiseException("Exception")
      _473 = torch.floordiv(torch.len(_470), 2)
      _474 = torch.le(_473, torch.dim(layer_input))
      if _474:
        pass
      else:
        ops.prim.RaiseException("Exception")
      if torch.eq("circular", "constant"):
        _475 = torch.constant_pad_nd(layer_input, _470, 0.)
      else:
        if torch.eq(0., 0):
          pass
        else:
          ops.prim.RaiseException("Exception")
        _476 = torch.eq(torch.dim(layer_input), 3)
        if _476:
          if torch.eq(torch.len(_470), 2):
            pass
          else:
            ops.prim.RaiseException("Exception")
          _478 = torch.eq("circular", "reflect")
          if _478:
            _479 = torch.reflection_pad1d(layer_input, _470)
          else:
            _480 = torch.eq("circular", "replicate")
            if _480:
              _481 = torch.replication_pad1d(layer_input, _470)
            else:
              _482 = torch.eq("circular", "circular")
              if _482:
                _484 = torch.slice(layer_input, 0, 0, 9223372036854775807, 1)
                _485 = torch.slice(_484, 1, 0, 9223372036854775807, 1)
                _486 = torch.slice(_485, 2, 0, _470[-1], 1)
                input = torch.cat([layer_input, _486], 2)
                _487 = torch.slice(input, 0, 0, 9223372036854775807, 1)
                _488 = torch.add(_470[-1], _470[-2])
                _489 = torch.slice(_487, 1, 0, 9223372036854775807, 1)
                _490 = torch.slice(_489, 2, torch.neg(_488), torch.neg(_470[-1]), 1)
                input53 = torch.cat([_490, input], 2)
                _491 = torch.gt(torch.len(_470), 2)
                if _491:
                  _492 = torch.slice(input53, 0, 0, 9223372036854775807, 1)
                  _493 = torch.slice(_492, 1, 0, 9223372036854775807, 1)
                  _494 = torch.slice(_493, 2, 0, 9223372036854775807, 1)
                  _495 = torch.slice(_494, 3, 0, _470[-3], 1)
                  input55 = torch.cat([input53, _495], 3)
                  _496 = torch.slice(input55, 0, 0, 9223372036854775807, 1)
                  _497 = torch.slice(_496, 1, 0, 9223372036854775807, 1)
                  _498 = torch.add(_470[-3], _470[-4])
                  _499 = torch.slice(_497, 2, 0, 9223372036854775807, 1)
                  _500 = torch.slice(_499, 3, torch.neg(_498), torch.neg(_470[-3]), 1)
                  input54 = torch.cat([_500, input55], 3)
                else:
                  input54 = input53
                _501 = torch.gt(torch.len(_470), 4)
                if _501:
                  _502 = torch.slice(input54, 0, 0, 9223372036854775807, 1)
                  _503 = torch.slice(_502, 1, 0, 9223372036854775807, 1)
                  _504 = torch.slice(_503, 2, 0, 9223372036854775807, 1)
                  _505 = torch.slice(_504, 3, 0, 9223372036854775807, 1)
                  _506 = torch.slice(_505, 4, 0, _470[-5], 1)
                  input57 = torch.cat([input54, _506], 4)
                  _507 = torch.slice(input57, 0, 0, 9223372036854775807, 1)
                  _508 = torch.slice(_507, 1, 0, 9223372036854775807, 1)
                  _509 = torch.slice(_508, 2, 0, 9223372036854775807, 1)
                  _510 = torch.add(_470[-5], _470[-6])
                  _511 = torch.slice(_509, 3, 0, 9223372036854775807, 1)
                  _512 = torch.slice(_511, 4, torch.neg(_510), torch.neg(_470[-5]), 1)
                  input56 = torch.cat([_512, input57], 4)
                else:
                  input56 = input54
                _483 = input56
              else:
                ops.prim.RaiseException("Exception")
                _483 = _471
              _481 = _483
            _479 = _481
          _477 = _479
        else:
          _513 = torch.eq(torch.dim(layer_input), 4)
          if _513:
            _515 = torch.eq(torch.len(_470), 4)
            if _515:
              pass
            else:
              ops.prim.RaiseException("Exception")
            _516 = torch.eq("circular", "reflect")
            if _516:
              _517 = torch.reflection_pad2d(layer_input, _470)
            else:
              _518 = torch.eq("circular", "replicate")
              if _518:
                _519 = torch.replication_pad2d(layer_input, _470)
              else:
                _520 = torch.eq("circular", "circular")
                if _520:
                  _522 = torch.slice(layer_input, 0, 0, 9223372036854775807, 1)
                  _523 = torch.slice(_522, 1, 0, 9223372036854775807, 1)
                  _524 = torch.slice(_523, 2, 0, _470[-1], 1)
                  input58 = torch.cat([layer_input, _524], 2)
                  _525 = torch.slice(input58, 0, 0, 9223372036854775807, 1)
                  _526 = torch.add(_470[-1], _470[-2])
                  _527 = torch.slice(_525, 1, 0, 9223372036854775807, 1)
                  _528 = torch.slice(_527, 2, torch.neg(_526), torch.neg(_470[-1]), 1)
                  input59 = torch.cat([_528, input58], 2)
                  _529 = torch.gt(torch.len(_470), 2)
                  if _529:
                    _530 = torch.slice(input59, 0, 0, 9223372036854775807, 1)
                    _531 = torch.slice(_530, 1, 0, 9223372036854775807, 1)
                    _532 = torch.slice(_531, 2, 0, 9223372036854775807, 1)
                    _533 = torch.slice(_532, 3, 0, _470[-3], 1)
                    input61 = torch.cat([input59, _533], 3)
                    _534 = torch.slice(input61, 0, 0, 9223372036854775807, 1)
                    _535 = torch.slice(_534, 1, 0, 9223372036854775807, 1)
                    _536 = torch.add(_470[-3], _470[-4])
                    _537 = torch.slice(_535, 2, 0, 9223372036854775807, 1)
                    _538 = torch.slice(_537, 3, torch.neg(_536), torch.neg(_470[-3]), 1)
                    input60 = torch.cat([_538, input61], 3)
                  else:
                    input60 = input59
                  _539 = torch.gt(torch.len(_470), 4)
                  if _539:
                    _540 = torch.slice(input60, 0, 0, 9223372036854775807, 1)
                    _541 = torch.slice(_540, 1, 0, 9223372036854775807, 1)
                    _542 = torch.slice(_541, 2, 0, 9223372036854775807, 1)
                    _543 = torch.slice(_542, 3, 0, 9223372036854775807, 1)
                    _544 = torch.slice(_543, 4, 0, _470[-5], 1)
                    input63 = torch.cat([input60, _544], 4)
                    _545 = torch.slice(input63, 0, 0, 9223372036854775807, 1)
                    _546 = torch.slice(_545, 1, 0, 9223372036854775807, 1)
                    _547 = torch.slice(_546, 2, 0, 9223372036854775807, 1)
                    _548 = torch.add(_470[-5], _470[-6])
                    _549 = torch.slice(_547, 3, 0, 9223372036854775807, 1)
                    _550 = torch.slice(_549, 4, torch.neg(_548), torch.neg(_470[-5]), 1)
                    input62 = torch.cat([_550, input63], 4)
                  else:
                    input62 = input60
                  _521 = input62
                else:
                  ops.prim.RaiseException("Exception")
                  _521 = _471
                _519 = _521
              _517 = _519
            _514 = _517
          else:
            _551 = torch.eq(torch.dim(layer_input), 5)
            if _551:
              _553 = torch.eq(torch.len(_470), 6)
              if _553:
                pass
              else:
                ops.prim.RaiseException("Exception")
              _554 = torch.eq("circular", "reflect")
              if _554:
                ops.prim.RaiseException("Exception")
                _555 = _471
              else:
                _556 = torch.eq("circular", "replicate")
                if _556:
                  _557 = torch.replication_pad3d(layer_input, _470)
                else:
                  _558 = torch.eq("circular", "circular")
                  if _558:
                    _560 = torch.slice(layer_input, 0, 0, 9223372036854775807, 1)
                    _561 = torch.slice(_560, 1, 0, 9223372036854775807, 1)
                    _562 = torch.slice(_561, 2, 0, _470[-1], 1)
                    input64 = torch.cat([layer_input, _562], 2)
                    _563 = torch.slice(input64, 0, 0, 9223372036854775807, 1)
                    _564 = torch.add(_470[-1], _470[-2])
                    _565 = torch.slice(_563, 1, 0, 9223372036854775807, 1)
                    _566 = torch.slice(_565, 2, torch.neg(_564), torch.neg(_470[-1]), 1)
                    input65 = torch.cat([_566, input64], 2)
                    _567 = torch.gt(torch.len(_470), 2)
                    if _567:
                      _568 = torch.slice(input65, 0, 0, 9223372036854775807, 1)
                      _569 = torch.slice(_568, 1, 0, 9223372036854775807, 1)
                      _570 = torch.slice(_569, 2, 0, 9223372036854775807, 1)
                      _571 = torch.slice(_570, 3, 0, _470[-3], 1)
                      input67 = torch.cat([input65, _571], 3)
                      _572 = torch.slice(input67, 0, 0, 9223372036854775807, 1)
                      _573 = torch.slice(_572, 1, 0, 9223372036854775807, 1)
                      _574 = torch.add(_470[-3], _470[-4])
                      _575 = torch.slice(_573, 2, 0, 9223372036854775807, 1)
                      _576 = torch.neg(_574)
                      _577 = torch.neg(_470[-3])
                      _578 = torch.slice(_575, 3, _576, _577, 1)
                      input66 = torch.cat([_578, input67], 3)
                    else:
                      input66 = input65
                    _579 = torch.gt(torch.len(_470), 4)
                    if _579:
                      _580 = torch.slice(input66, 0, 0, 9223372036854775807, 1)
                      _581 = torch.slice(_580, 1, 0, 9223372036854775807, 1)
                      _582 = torch.slice(_581, 2, 0, 9223372036854775807, 1)
                      _583 = torch.slice(_582, 3, 0, 9223372036854775807, 1)
                      _584 = torch.slice(_583, 4, 0, _470[-5], 1)
                      input69 = torch.cat([input66, _584], 4)
                      _585 = torch.slice(input69, 0, 0, 9223372036854775807, 1)
                      _586 = torch.slice(_585, 1, 0, 9223372036854775807, 1)
                      _587 = torch.slice(_586, 2, 0, 9223372036854775807, 1)
                      _588 = torch.add(_470[-5], _470[-6])
                      _589 = torch.slice(_587, 3, 0, 9223372036854775807, 1)
                      _590 = torch.neg(_588)
                      _591 = torch.neg(_470[-5])
                      _592 = torch.slice(_589, 4, _590, _591, 1)
                      input68 = torch.cat([_592, input69], 4)
                    else:
                      input68 = input66
                    _559 = input68
                  else:
                    ops.prim.RaiseException("Exception")
                    _559 = _471
                  _557 = _559
                _555 = _557
              _552 = _555
            else:
              ops.prim.RaiseException("Exception")
              _552 = _471
            _514 = _552
          _477 = _514
        _475 = _477
      _593 = _462.bias
      _594 = [0, 0]
      _465, _466 = True, torch.conv2d(_475, _463, _593, [1, 1], _594, [1, 1], 1)
    else:
      _465, _466 = False, _464
    if _465:
      _595 = _466
    else:
      _595 = torch.conv2d(layer_input, _463, _462.bias, [1, 1], [0, 0], [1, 1], 1)
    if False:
      layer_input10 = torch.relu_(_595)
    else:
      layer_input10 = torch.relu(_595)
    _596 = [2, 2]
    _597 = [2, 2]
    _598 = [0, 0]
    _599 = [1, 1]
    if torch.__is__(_597, None):
      stride = annotate(List[int], [])
    else:
      stride = ops.prim.unchecked_unwrap_optional(_597)
    layer_input11 = torch.max_pool2d(layer_input10, _596, stride, _598, _599, False)
    _600 = self.encoder_h1
    _601 = _600.weight
    _602 = uninitialized(Tensor)
    if torch.eq("zeros", "circular"):
      _605 = torch.floordiv(torch.add(0, 1), 2)
      _606 = torch.floordiv(0, 2)
      _607 = torch.floordiv(torch.add(0, 1), 2)
      _608 = [_605, _606, _607, torch.floordiv(0, 2)]
      _609 = uninitialized(Tensor)
      _610 = torch.remainder(torch.len(_608), 2)
      if torch.eq(_610, 0):
        pass
      else:
        ops.prim.RaiseException("Exception")
      _611 = torch.floordiv(torch.len(_608), 2)
      _612 = torch.le(_611, torch.dim(layer_input11))
      if _612:
        pass
      else:
        ops.prim.RaiseException("Exception")
      if torch.eq("circular", "constant"):
        _613 = torch.constant_pad_nd(layer_input11, _608, 0.)
      else:
        if torch.eq(0., 0):
          pass
        else:
          ops.prim.RaiseException("Exception")
        _614 = torch.eq(torch.dim(layer_input11), 3)
        if _614:
          if torch.eq(torch.len(_608), 2):
            pass
          else:
            ops.prim.RaiseException("Exception")
          _616 = torch.eq("circular", "reflect")
          if _616:
            _617 = torch.reflection_pad1d(layer_input11, _608)
          else:
            _618 = torch.eq("circular", "replicate")
            if _618:
              _619 = torch.replication_pad1d(layer_input11, _608)
            else:
              _620 = torch.eq("circular", "circular")
              if _620:
                _622 = torch.slice(layer_input11, 0, 0, 9223372036854775807, 1)
                _623 = torch.slice(_622, 1, 0, 9223372036854775807, 1)
                _624 = torch.slice(_623, 2, 0, _608[-1], 1)
                input70 = torch.cat([layer_input11, _624], 2)
                _625 = torch.slice(input70, 0, 0, 9223372036854775807, 1)
                _626 = torch.add(_608[-1], _608[-2])
                _627 = torch.slice(_625, 1, 0, 9223372036854775807, 1)
                _628 = torch.slice(_627, 2, torch.neg(_626), torch.neg(_608[-1]), 1)
                input71 = torch.cat([_628, input70], 2)
                _629 = torch.gt(torch.len(_608), 2)
                if _629:
                  _630 = torch.slice(input71, 0, 0, 9223372036854775807, 1)
                  _631 = torch.slice(_630, 1, 0, 9223372036854775807, 1)
                  _632 = torch.slice(_631, 2, 0, 9223372036854775807, 1)
                  _633 = torch.slice(_632, 3, 0, _608[-3], 1)
                  input73 = torch.cat([input71, _633], 3)
                  _634 = torch.slice(input73, 0, 0, 9223372036854775807, 1)
                  _635 = torch.slice(_634, 1, 0, 9223372036854775807, 1)
                  _636 = torch.add(_608[-3], _608[-4])
                  _637 = torch.slice(_635, 2, 0, 9223372036854775807, 1)
                  _638 = torch.slice(_637, 3, torch.neg(_636), torch.neg(_608[-3]), 1)
                  input72 = torch.cat([_638, input73], 3)
                else:
                  input72 = input71
                _639 = torch.gt(torch.len(_608), 4)
                if _639:
                  _640 = torch.slice(input72, 0, 0, 9223372036854775807, 1)
                  _641 = torch.slice(_640, 1, 0, 9223372036854775807, 1)
                  _642 = torch.slice(_641, 2, 0, 9223372036854775807, 1)
                  _643 = torch.slice(_642, 3, 0, 9223372036854775807, 1)
                  _644 = torch.slice(_643, 4, 0, _608[-5], 1)
                  input75 = torch.cat([input72, _644], 4)
                  _645 = torch.slice(input75, 0, 0, 9223372036854775807, 1)
                  _646 = torch.slice(_645, 1, 0, 9223372036854775807, 1)
                  _647 = torch.slice(_646, 2, 0, 9223372036854775807, 1)
                  _648 = torch.add(_608[-5], _608[-6])
                  _649 = torch.slice(_647, 3, 0, 9223372036854775807, 1)
                  _650 = torch.slice(_649, 4, torch.neg(_648), torch.neg(_608[-5]), 1)
                  input74 = torch.cat([_650, input75], 4)
                else:
                  input74 = input72
                _621 = input74
              else:
                ops.prim.RaiseException("Exception")
                _621 = _609
              _619 = _621
            _617 = _619
          _615 = _617
        else:
          _651 = torch.eq(torch.dim(layer_input11), 4)
          if _651:
            _653 = torch.eq(torch.len(_608), 4)
            if _653:
              pass
            else:
              ops.prim.RaiseException("Exception")
            _654 = torch.eq("circular", "reflect")
            if _654:
              _655 = torch.reflection_pad2d(layer_input11, _608)
            else:
              _656 = torch.eq("circular", "replicate")
              if _656:
                _657 = torch.replication_pad2d(layer_input11, _608)
              else:
                _658 = torch.eq("circular", "circular")
                if _658:
                  _660 = torch.slice(layer_input11, 0, 0, 9223372036854775807, 1)
                  _661 = torch.slice(_660, 1, 0, 9223372036854775807, 1)
                  _662 = torch.slice(_661, 2, 0, _608[-1], 1)
                  input76 = torch.cat([layer_input11, _662], 2)
                  _663 = torch.slice(input76, 0, 0, 9223372036854775807, 1)
                  _664 = torch.add(_608[-1], _608[-2])
                  _665 = torch.slice(_663, 1, 0, 9223372036854775807, 1)
                  _666 = torch.slice(_665, 2, torch.neg(_664), torch.neg(_608[-1]), 1)
                  input77 = torch.cat([_666, input76], 2)
                  _667 = torch.gt(torch.len(_608), 2)
                  if _667:
                    _668 = torch.slice(input77, 0, 0, 9223372036854775807, 1)
                    _669 = torch.slice(_668, 1, 0, 9223372036854775807, 1)
                    _670 = torch.slice(_669, 2, 0, 9223372036854775807, 1)
                    _671 = torch.slice(_670, 3, 0, _608[-3], 1)
                    input79 = torch.cat([input77, _671], 3)
                    _672 = torch.slice(input79, 0, 0, 9223372036854775807, 1)
                    _673 = torch.slice(_672, 1, 0, 9223372036854775807, 1)
                    _674 = torch.add(_608[-3], _608[-4])
                    _675 = torch.slice(_673, 2, 0, 9223372036854775807, 1)
                    _676 = torch.slice(_675, 3, torch.neg(_674), torch.neg(_608[-3]), 1)
                    input78 = torch.cat([_676, input79], 3)
                  else:
                    input78 = input77
                  _677 = torch.gt(torch.len(_608), 4)
                  if _677:
                    _678 = torch.slice(input78, 0, 0, 9223372036854775807, 1)
                    _679 = torch.slice(_678, 1, 0, 9223372036854775807, 1)
                    _680 = torch.slice(_679, 2, 0, 9223372036854775807, 1)
                    _681 = torch.slice(_680, 3, 0, 9223372036854775807, 1)
                    _682 = torch.slice(_681, 4, 0, _608[-5], 1)
                    input81 = torch.cat([input78, _682], 4)
                    _683 = torch.slice(input81, 0, 0, 9223372036854775807, 1)
                    _684 = torch.slice(_683, 1, 0, 9223372036854775807, 1)
                    _685 = torch.slice(_684, 2, 0, 9223372036854775807, 1)
                    _686 = torch.add(_608[-5], _608[-6])
                    _687 = torch.slice(_685, 3, 0, 9223372036854775807, 1)
                    _688 = torch.slice(_687, 4, torch.neg(_686), torch.neg(_608[-5]), 1)
                    input80 = torch.cat([_688, input81], 4)
                  else:
                    input80 = input78
                  _659 = input80
                else:
                  ops.prim.RaiseException("Exception")
                  _659 = _609
                _657 = _659
              _655 = _657
            _652 = _655
          else:
            _689 = torch.eq(torch.dim(layer_input11), 5)
            if _689:
              _691 = torch.eq(torch.len(_608), 6)
              if _691:
                pass
              else:
                ops.prim.RaiseException("Exception")
              _692 = torch.eq("circular", "reflect")
              if _692:
                ops.prim.RaiseException("Exception")
                _693 = _609
              else:
                _694 = torch.eq("circular", "replicate")
                if _694:
                  _695 = torch.replication_pad3d(layer_input11, _608)
                else:
                  _696 = torch.eq("circular", "circular")
                  if _696:
                    _698 = torch.slice(layer_input11, 0, 0, 9223372036854775807, 1)
                    _699 = torch.slice(_698, 1, 0, 9223372036854775807, 1)
                    _700 = torch.slice(_699, 2, 0, _608[-1], 1)
                    _701 = [layer_input11, _700]
                    input82 = torch.cat(_701, 2)
                    _702 = torch.slice(input82, 0, 0, 9223372036854775807, 1)
                    _703 = torch.add(_608[-1], _608[-2])
                    _704 = torch.slice(_702, 1, 0, 9223372036854775807, 1)
                    _705 = torch.slice(_704, 2, torch.neg(_703), torch.neg(_608[-1]), 1)
                    input83 = torch.cat([_705, input82], 2)
                    _706 = torch.gt(torch.len(_608), 2)
                    if _706:
                      _707 = torch.slice(input83, 0, 0, 9223372036854775807, 1)
                      _708 = torch.slice(_707, 1, 0, 9223372036854775807, 1)
                      _709 = torch.slice(_708, 2, 0, 9223372036854775807, 1)
                      _710 = torch.slice(_709, 3, 0, _608[-3], 1)
                      input85 = torch.cat([input83, _710], 3)
                      _711 = torch.slice(input85, 0, 0, 9223372036854775807, 1)
                      _712 = torch.slice(_711, 1, 0, 9223372036854775807, 1)
                      _713 = torch.add(_608[-3], _608[-4])
                      _714 = torch.slice(_712, 2, 0, 9223372036854775807, 1)
                      _715 = torch.neg(_713)
                      _716 = torch.neg(_608[-3])
                      _717 = torch.slice(_714, 3, _715, _716, 1)
                      input84 = torch.cat([_717, input85], 3)
                    else:
                      input84 = input83
                    _718 = torch.gt(torch.len(_608), 4)
                    if _718:
                      _719 = torch.slice(input84, 0, 0, 9223372036854775807, 1)
                      _720 = torch.slice(_719, 1, 0, 9223372036854775807, 1)
                      _721 = torch.slice(_720, 2, 0, 9223372036854775807, 1)
                      _722 = torch.slice(_721, 3, 0, 9223372036854775807, 1)
                      _723 = torch.slice(_722, 4, 0, _608[-5], 1)
                      input87 = torch.cat([input84, _723], 4)
                      _724 = torch.slice(input87, 0, 0, 9223372036854775807, 1)
                      _725 = torch.slice(_724, 1, 0, 9223372036854775807, 1)
                      _726 = torch.slice(_725, 2, 0, 9223372036854775807, 1)
                      _727 = torch.add(_608[-5], _608[-6])
                      _728 = torch.slice(_726, 3, 0, 9223372036854775807, 1)
                      _729 = torch.neg(_727)
                      _730 = torch.neg(_608[-5])
                      _731 = torch.slice(_728, 4, _729, _730, 1)
                      input86 = torch.cat([_731, input87], 4)
                    else:
                      input86 = input84
                    _697 = input86
                  else:
                    ops.prim.RaiseException("Exception")
                    _697 = _609
                  _695 = _697
                _693 = _695
              _690 = _693
            else:
              ops.prim.RaiseException("Exception")
              _690 = _609
            _652 = _690
          _615 = _652
        _613 = _615
      _732 = _600.bias
      _733 = [0, 0]
      _603, _604 = True, torch.conv2d(_613, _601, _732, [1, 1], _733, [1, 1], 1)
    else:
      _603, _604 = False, _602
    if _603:
      _734 = _604
    else:
      _734 = torch.conv2d(layer_input11, _601, _600.bias, [1, 1], [0, 0], [1, 1], 1)
    if False:
      layer_input12 = torch.relu_(_734)
    else:
      layer_input12 = torch.relu(_734)
    _735 = [2, 2]
    _736 = [2, 2]
    _737 = [0, 0]
    _738 = [1, 1]
    if torch.__is__(_736, None):
      stride2 = annotate(List[int], [])
    else:
      stride2 = ops.prim.unchecked_unwrap_optional(_736)
    layer_input13 = torch.max_pool2d(layer_input12, _735, stride2, _737, _738, False)
    _739 = self.encoder_h2
    _740 = _739.weight
    _741 = uninitialized(Tensor)
    if torch.eq("zeros", "circular"):
      _744 = torch.floordiv(torch.add(0, 1), 2)
      _745 = torch.floordiv(0, 2)
      _746 = torch.floordiv(torch.add(0, 1), 2)
      _747 = [_744, _745, _746, torch.floordiv(0, 2)]
      _748 = uninitialized(Tensor)
      _749 = torch.remainder(torch.len(_747), 2)
      if torch.eq(_749, 0):
        pass
      else:
        ops.prim.RaiseException("Exception")
      _750 = torch.floordiv(torch.len(_747), 2)
      _751 = torch.le(_750, torch.dim(layer_input13))
      if _751:
        pass
      else:
        ops.prim.RaiseException("Exception")
      if torch.eq("circular", "constant"):
        _752 = torch.constant_pad_nd(layer_input13, _747, 0.)
      else:
        if torch.eq(0., 0):
          pass
        else:
          ops.prim.RaiseException("Exception")
        _753 = torch.eq(torch.dim(layer_input13), 3)
        if _753:
          if torch.eq(torch.len(_747), 2):
            pass
          else:
            ops.prim.RaiseException("Exception")
          _755 = torch.eq("circular", "reflect")
          if _755:
            _756 = torch.reflection_pad1d(layer_input13, _747)
          else:
            _757 = torch.eq("circular", "replicate")
            if _757:
              _758 = torch.replication_pad1d(layer_input13, _747)
            else:
              _759 = torch.eq("circular", "circular")
              if _759:
                _761 = torch.slice(layer_input13, 0, 0, 9223372036854775807, 1)
                _762 = torch.slice(_761, 1, 0, 9223372036854775807, 1)
                _763 = torch.slice(_762, 2, 0, _747[-1], 1)
                input88 = torch.cat([layer_input13, _763], 2)
                _764 = torch.slice(input88, 0, 0, 9223372036854775807, 1)
                _765 = torch.add(_747[-1], _747[-2])
                _766 = torch.slice(_764, 1, 0, 9223372036854775807, 1)
                _767 = torch.slice(_766, 2, torch.neg(_765), torch.neg(_747[-1]), 1)
                input89 = torch.cat([_767, input88], 2)
                _768 = torch.gt(torch.len(_747), 2)
                if _768:
                  _769 = torch.slice(input89, 0, 0, 9223372036854775807, 1)
                  _770 = torch.slice(_769, 1, 0, 9223372036854775807, 1)
                  _771 = torch.slice(_770, 2, 0, 9223372036854775807, 1)
                  _772 = torch.slice(_771, 3, 0, _747[-3], 1)
                  input91 = torch.cat([input89, _772], 3)
                  _773 = torch.slice(input91, 0, 0, 9223372036854775807, 1)
                  _774 = torch.slice(_773, 1, 0, 9223372036854775807, 1)
                  _775 = torch.add(_747[-3], _747[-4])
                  _776 = torch.slice(_774, 2, 0, 9223372036854775807, 1)
                  _777 = torch.slice(_776, 3, torch.neg(_775), torch.neg(_747[-3]), 1)
                  input90 = torch.cat([_777, input91], 3)
                else:
                  input90 = input89
                _778 = torch.gt(torch.len(_747), 4)
                if _778:
                  _779 = torch.slice(input90, 0, 0, 9223372036854775807, 1)
                  _780 = torch.slice(_779, 1, 0, 9223372036854775807, 1)
                  _781 = torch.slice(_780, 2, 0, 9223372036854775807, 1)
                  _782 = torch.slice(_781, 3, 0, 9223372036854775807, 1)
                  _783 = torch.slice(_782, 4, 0, _747[-5], 1)
                  input93 = torch.cat([input90, _783], 4)
                  _784 = torch.slice(input93, 0, 0, 9223372036854775807, 1)
                  _785 = torch.slice(_784, 1, 0, 9223372036854775807, 1)
                  _786 = torch.slice(_785, 2, 0, 9223372036854775807, 1)
                  _787 = torch.add(_747[-5], _747[-6])
                  _788 = torch.slice(_786, 3, 0, 9223372036854775807, 1)
                  _789 = torch.slice(_788, 4, torch.neg(_787), torch.neg(_747[-5]), 1)
                  input92 = torch.cat([_789, input93], 4)
                else:
                  input92 = input90
                _760 = input92
              else:
                ops.prim.RaiseException("Exception")
                _760 = _748
              _758 = _760
            _756 = _758
          _754 = _756
        else:
          _790 = torch.eq(torch.dim(layer_input13), 4)
          if _790:
            _792 = torch.eq(torch.len(_747), 4)
            if _792:
              pass
            else:
              ops.prim.RaiseException("Exception")
            _793 = torch.eq("circular", "reflect")
            if _793:
              _794 = torch.reflection_pad2d(layer_input13, _747)
            else:
              _795 = torch.eq("circular", "replicate")
              if _795:
                _796 = torch.replication_pad2d(layer_input13, _747)
              else:
                _797 = torch.eq("circular", "circular")
                if _797:
                  _799 = torch.slice(layer_input13, 0, 0, 9223372036854775807, 1)
                  _800 = torch.slice(_799, 1, 0, 9223372036854775807, 1)
                  _801 = torch.slice(_800, 2, 0, _747[-1], 1)
                  input94 = torch.cat([layer_input13, _801], 2)
                  _802 = torch.slice(input94, 0, 0, 9223372036854775807, 1)
                  _803 = torch.add(_747[-1], _747[-2])
                  _804 = torch.slice(_802, 1, 0, 9223372036854775807, 1)
                  _805 = torch.slice(_804, 2, torch.neg(_803), torch.neg(_747[-1]), 1)
                  input95 = torch.cat([_805, input94], 2)
                  _806 = torch.gt(torch.len(_747), 2)
                  if _806:
                    _807 = torch.slice(input95, 0, 0, 9223372036854775807, 1)
                    _808 = torch.slice(_807, 1, 0, 9223372036854775807, 1)
                    _809 = torch.slice(_808, 2, 0, 9223372036854775807, 1)
                    _810 = torch.slice(_809, 3, 0, _747[-3], 1)
                    input97 = torch.cat([input95, _810], 3)
                    _811 = torch.slice(input97, 0, 0, 9223372036854775807, 1)
                    _812 = torch.slice(_811, 1, 0, 9223372036854775807, 1)
                    _813 = torch.add(_747[-3], _747[-4])
                    _814 = torch.slice(_812, 2, 0, 9223372036854775807, 1)
                    _815 = torch.slice(_814, 3, torch.neg(_813), torch.neg(_747[-3]), 1)
                    input96 = torch.cat([_815, input97], 3)
                  else:
                    input96 = input95
                  _816 = torch.gt(torch.len(_747), 4)
                  if _816:
                    _817 = torch.slice(input96, 0, 0, 9223372036854775807, 1)
                    _818 = torch.slice(_817, 1, 0, 9223372036854775807, 1)
                    _819 = torch.slice(_818, 2, 0, 9223372036854775807, 1)
                    _820 = torch.slice(_819, 3, 0, 9223372036854775807, 1)
                    _821 = torch.slice(_820, 4, 0, _747[-5], 1)
                    input99 = torch.cat([input96, _821], 4)
                    _822 = torch.slice(input99, 0, 0, 9223372036854775807, 1)
                    _823 = torch.slice(_822, 1, 0, 9223372036854775807, 1)
                    _824 = torch.slice(_823, 2, 0, 9223372036854775807, 1)
                    _825 = torch.add(_747[-5], _747[-6])
                    _826 = torch.slice(_824, 3, 0, 9223372036854775807, 1)
                    _827 = torch.slice(_826, 4, torch.neg(_825), torch.neg(_747[-5]), 1)
                    input98 = torch.cat([_827, input99], 4)
                  else:
                    input98 = input96
                  _798 = input98
                else:
                  ops.prim.RaiseException("Exception")
                  _798 = _748
                _796 = _798
              _794 = _796
            _791 = _794
          else:
            _828 = torch.eq(torch.dim(layer_input13), 5)
            if _828:
              _830 = torch.eq(torch.len(_747), 6)
              if _830:
                pass
              else:
                ops.prim.RaiseException("Exception")
              _831 = torch.eq("circular", "reflect")
              if _831:
                ops.prim.RaiseException("Exception")
                _832 = _748
              else:
                _833 = torch.eq("circular", "replicate")
                if _833:
                  _834 = torch.replication_pad3d(layer_input13, _747)
                else:
                  _835 = torch.eq("circular", "circular")
                  if _835:
                    _837 = torch.slice(layer_input13, 0, 0, 9223372036854775807, 1)
                    _838 = torch.slice(_837, 1, 0, 9223372036854775807, 1)
                    _839 = torch.slice(_838, 2, 0, _747[-1], 1)
                    _840 = [layer_input13, _839]
                    input100 = torch.cat(_840, 2)
                    _841 = torch.slice(input100, 0, 0, 9223372036854775807, 1)
                    _842 = torch.add(_747[-1], _747[-2])
                    _843 = torch.slice(_841, 1, 0, 9223372036854775807, 1)
                    _844 = torch.slice(_843, 2, torch.neg(_842), torch.neg(_747[-1]), 1)
                    input101 = torch.cat([_844, input100], 2)
                    _845 = torch.gt(torch.len(_747), 2)
                    if _845:
                      _846 = torch.slice(input101, 0, 0, 9223372036854775807, 1)
                      _847 = torch.slice(_846, 1, 0, 9223372036854775807, 1)
                      _848 = torch.slice(_847, 2, 0, 9223372036854775807, 1)
                      _849 = torch.slice(_848, 3, 0, _747[-3], 1)
                      input103 = torch.cat([input101, _849], 3)
                      _850 = torch.slice(input103, 0, 0, 9223372036854775807, 1)
                      _851 = torch.slice(_850, 1, 0, 9223372036854775807, 1)
                      _852 = torch.add(_747[-3], _747[-4])
                      _853 = torch.slice(_851, 2, 0, 9223372036854775807, 1)
                      _854 = torch.neg(_852)
                      _855 = torch.neg(_747[-3])
                      _856 = torch.slice(_853, 3, _854, _855, 1)
                      input102 = torch.cat([_856, input103], 3)
                    else:
                      input102 = input101
                    _857 = torch.gt(torch.len(_747), 4)
                    if _857:
                      _858 = torch.slice(input102, 0, 0, 9223372036854775807, 1)
                      _859 = torch.slice(_858, 1, 0, 9223372036854775807, 1)
                      _860 = torch.slice(_859, 2, 0, 9223372036854775807, 1)
                      _861 = torch.slice(_860, 3, 0, 9223372036854775807, 1)
                      _862 = torch.slice(_861, 4, 0, _747[-5], 1)
                      input105 = torch.cat([input102, _862], 4)
                      _863 = torch.slice(input105, 0, 0, 9223372036854775807, 1)
                      _864 = torch.slice(_863, 1, 0, 9223372036854775807, 1)
                      _865 = torch.slice(_864, 2, 0, 9223372036854775807, 1)
                      _866 = torch.add(_747[-5], _747[-6])
                      _867 = torch.slice(_865, 3, 0, 9223372036854775807, 1)
                      _868 = torch.neg(_866)
                      _869 = torch.neg(_747[-5])
                      _870 = torch.slice(_867, 4, _868, _869, 1)
                      input104 = torch.cat([_870, input105], 4)
                    else:
                      input104 = input102
                    _836 = input104
                  else:
                    ops.prim.RaiseException("Exception")
                    _836 = _748
                  _834 = _836
                _832 = _834
              _829 = _832
            else:
              ops.prim.RaiseException("Exception")
              _829 = _748
            _791 = _829
          _754 = _791
        _752 = _754
      _871 = _739.bias
      _872 = [0, 0]
      _742, _743 = True, torch.conv2d(_752, _740, _871, [1, 1], _872, [1, 1], 1)
    else:
      _742, _743 = False, _741
    if _742:
      _873 = _743
    else:
      _873 = torch.conv2d(layer_input13, _740, _739.bias, [1, 1], [0, 0], [1, 1], 1)
    if False:
      layer_input14 = torch.relu_(_873)
    else:
      layer_input14 = torch.relu(_873)
    _874 = [2, 2]
    _875 = [2, 2]
    _876 = [0, 0]
    _877 = [1, 1]
    if torch.__is__(_875, None):
      stride3 = annotate(List[int], [])
    else:
      stride3 = ops.prim.unchecked_unwrap_optional(_875)
    layer_input15 = torch.max_pool2d(layer_input14, _874, stride3, _876, _877, False)
    layer_input16 = torch.flatten(layer_input15, 1, -1)
    _878 = self.encoder_mu
    _879 = _878.weight
    _880 = _878.bias
    _881 = torch.eq(torch.dim(layer_input16), 2)
    if _881:
      _882 = torch.__isnot__(_880, None)
    else:
      _882 = False
    if _882:
      bias = ops.prim.unchecked_unwrap_optional(_880)
      gaussian_param_mu = torch.addmm(bias, layer_input16, torch.t(_879), beta=1, alpha=1)
    else:
      output = torch.matmul(layer_input16, torch.t(_879))
      if torch.__isnot__(_880, None):
        bias5 = ops.prim.unchecked_unwrap_optional(_880)
        output5 = torch.add_(output, bias5, alpha=1)
      else:
        output5 = output
      gaussian_param_mu = output5
    _883 = self.encoder_output
    _884 = _883.weight
    _885 = _883.bias
    _886 = torch.eq(torch.dim(gaussian_param_mu), 2)
    if _886:
      _887 = torch.__isnot__(_885, None)
    else:
      _887 = False
    if _887:
      bias6 = ops.prim.unchecked_unwrap_optional(_885)
      gaussian_param_log_sigma = torch.addmm(bias6, gaussian_param_mu, torch.t(_884), beta=1, alpha=1)
    else:
      output6 = torch.matmul(gaussian_param_mu, torch.t(_884))
      if torch.__isnot__(_885, None):
        bias7 = ops.prim.unchecked_unwrap_optional(_885)
        output7 = torch.add_(output6, bias7, alpha=1)
      else:
        output7 = output6
      gaussian_param_log_sigma = output7
    _888 = (gaussian_param_mu, gaussian_param_log_sigma)
    return _888
  def reparameterize(self: __torch__.tofu.Tofu,
    mu: Tensor,
    log_sigma: Tensor) -> Tensor:
    std = torch.exp(torch.div(log_sigma, 2))
    eps = torch.randn_like(std)
    _889 = torch.add(mu, torch.mul(std, eps), alpha=1)
    return _889
  def decode(self: __torch__.tofu.Tofu,
    layer_input: Tensor) -> Tensor:
    _890 = self.decoder_input
    _891 = _890.weight
    _892 = _890.bias
    if torch.eq(torch.dim(layer_input), 2):
      _893 = torch.__isnot__(_892, None)
    else:
      _893 = False
    if _893:
      bias = ops.prim.unchecked_unwrap_optional(_892)
      ret = torch.addmm(bias, layer_input, torch.t(_891), beta=1, alpha=1)
    else:
      output = torch.matmul(layer_input, torch.t(_891))
      if torch.__isnot__(_892, None):
        bias8 = ops.prim.unchecked_unwrap_optional(_892)
        output8 = torch.add_(output, bias8, alpha=1)
      else:
        output8 = output
      ret = output8
    if False:
      layer_input17 = torch.relu_(ret)
    else:
      layer_input17 = torch.relu(ret)
    _894 = int(torch.div((self.input_shape)[0], 4))
    _895 = int(torch.div((self.input_shape)[1], 4))
    _896 = [(torch.size(layer_input17))[0], 32, torch.sub(_894, 1), torch.sub(_895, 1)]
    layer_input18 = torch.view(layer_input17, _896)
    _897 = self.decoder_h1
    if torch.ne("zeros", "zeros"):
      ops.prim.RaiseException("Exception")
    else:
      pass
    _898 = [2, 2]
    _899 = [0, 0]
    _900 = [3, 3]
    if torch.__is__(None, None):
      output_padding = [0, 0]
    else:
      output_size = ops.prim.unchecked_unwrap_optional(annotate(Optional[List[int]], None))
      k = torch.sub(torch.dim(layer_input18), 2)
      _901 = torch.eq(torch.len(output_size), torch.add(k, 2))
      if _901:
        output_size3 = torch.slice(output_size, 2, 9223372036854775807, 1)
      else:
        output_size3 = output_size
      _902 = torch.ne(torch.len(output_size3), k)
      if _902:
        ops.prim.RaiseException("Exception")
      else:
        pass
      min_sizes = annotate(List[int], [])
      max_sizes = annotate(List[int], [])
      for d in range(k):
        _903 = torch.size(layer_input18, torch.add(d, 2))
        _904 = torch.mul(torch.sub(_903, 1), _898[d])
        _905 = torch.sub(_904, torch.mul(2, _899[d]))
        dim_size = torch.add(_905, _900[d])
        _906 = torch.append(min_sizes, dim_size)
        _907 = torch.add(min_sizes[d], _898[d])
        _908 = torch.append(max_sizes, torch.sub(_907, 1))
      for i in range(torch.len(output_size3)):
        size = output_size3[i]
        min_size = min_sizes[i]
        max_size = max_sizes[i]
        if torch.lt(size, min_size):
          _909 = True
        else:
          _909 = torch.gt(size, max_size)
        if _909:
          ops.prim.RaiseException("Exception")
        else:
          pass
      res = annotate(List[int], [])
      for d3 in range(k):
        _910 = torch.sub(output_size3[d3], min_sizes[d3])
        _911 = torch.append(res, _910)
      output_padding = res
    _912 = torch.conv_transpose2d(layer_input18, _897.weight, _897.bias, [2, 2], [0, 0], output_padding, 1, [1, 1])
    if False:
      layer_input19 = torch.relu_(_912)
    else:
      layer_input19 = torch.relu(_912)
    _913 = self.decoder_h2
    if torch.ne("zeros", "zeros"):
      ops.prim.RaiseException("Exception")
    else:
      pass
    _914 = [2, 2]
    _915 = [0, 0]
    _916 = [3, 3]
    if torch.__is__(None, None):
      output_padding1 = [1, 1]
    else:
      output_size4 = ops.prim.unchecked_unwrap_optional(annotate(Optional[List[int]], None))
      k1 = torch.sub(torch.dim(layer_input19), 2)
      _917 = torch.eq(torch.len(output_size4), torch.add(k1, 2))
      if _917:
        output_size5 = torch.slice(output_size4, 2, 9223372036854775807, 1)
      else:
        output_size5 = output_size4
      _918 = torch.ne(torch.len(output_size5), k1)
      if _918:
        ops.prim.RaiseException("Exception")
      else:
        pass
      min_sizes1 = annotate(List[int], [])
      max_sizes1 = annotate(List[int], [])
      for d4 in range(k1):
        _919 = torch.size(layer_input19, torch.add(d4, 2))
        _920 = torch.mul(torch.sub(_919, 1), _914[d4])
        _921 = torch.sub(_920, torch.mul(2, _915[d4]))
        dim_size1 = torch.add(_921, _916[d4])
        _922 = torch.append(min_sizes1, dim_size1)
        _923 = torch.add(min_sizes1[d4], _914[d4])
        _924 = torch.append(max_sizes1, torch.sub(_923, 1))
      for i1 in range(torch.len(output_size5)):
        size1 = output_size5[i1]
        min_size1 = min_sizes1[i1]
        max_size1 = max_sizes1[i1]
        if torch.lt(size1, min_size1):
          _925 = True
        else:
          _925 = torch.gt(size1, max_size1)
        if _925:
          ops.prim.RaiseException("Exception")
        else:
          pass
      res1 = annotate(List[int], [])
      for d5 in range(k1):
        _926 = torch.sub(output_size5[d5], min_sizes1[d5])
        _927 = torch.append(res1, _926)
      output_padding1 = res1
    _928 = torch.conv_transpose2d(layer_input19, _913.weight, _913.bias, [2, 2], [0, 0], output_padding1, 1, [1, 1])
    return torch.sigmoid(_928)
