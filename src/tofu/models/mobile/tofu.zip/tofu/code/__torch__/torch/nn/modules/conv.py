op_version_set = 1
class Conv2d(Module):
  __parameters__ = ["bias", "weight", ]
  training : bool
  bias : Tensor
  weight : Tensor
  __constants__ : List[str]
  transposed : bool
  def forward(self: __torch__.torch.nn.modules.conv.Conv2d,
    input: Tensor) -> Tensor:
    _0 = self.weight
    _1 = uninitialized(Tensor)
    if torch.eq("zeros", "circular"):
      _4 = torch.floordiv(torch.add(0, 1), 2)
      _5 = torch.floordiv(0, 2)
      _6 = torch.floordiv(torch.add(0, 1), 2)
      _7 = [_4, _5, _6, torch.floordiv(0, 2)]
      _8 = uninitialized(Tensor)
      _9 = torch.eq(torch.remainder(torch.len(_7), 2), 0)
      if _9:
        pass
      else:
        ops.prim.RaiseException("Exception")
      _10 = torch.le(torch.floordiv(torch.len(_7), 2), torch.dim(input))
      if _10:
        pass
      else:
        ops.prim.RaiseException("Exception")
      if torch.eq("circular", "constant"):
        _11 = torch.constant_pad_nd(input, _7, 0.)
      else:
        if torch.eq(0., 0):
          pass
        else:
          ops.prim.RaiseException("Exception")
        if torch.eq(torch.dim(input), 3):
          if torch.eq(torch.len(_7), 2):
            pass
          else:
            ops.prim.RaiseException("Exception")
          _13 = torch.eq("circular", "reflect")
          if _13:
            _14 = torch.reflection_pad1d(input, _7)
          else:
            _15 = torch.eq("circular", "replicate")
            if _15:
              _16 = torch.replication_pad1d(input, _7)
            else:
              _17 = torch.eq("circular", "circular")
              if _17:
                _19 = torch.slice(input, 0, 0, 9223372036854775807, 1)
                _20 = torch.slice(_19, 1, 0, 9223372036854775807, 1)
                _21 = torch.slice(_20, 2, 0, _7[-1], 1)
                input0 = torch.cat([input, _21], 2)
                _22 = torch.slice(input0, 0, 0, 9223372036854775807, 1)
                _23 = torch.add(_7[-1], _7[-2])
                _24 = torch.slice(_22, 1, 0, 9223372036854775807, 1)
                _25 = torch.slice(_24, 2, torch.neg(_23), torch.neg(_7[-1]), 1)
                input1 = torch.cat([_25, input0], 2)
                _26 = torch.gt(torch.len(_7), 2)
                if _26:
                  _27 = torch.slice(input1, 0, 0, 9223372036854775807, 1)
                  _28 = torch.slice(_27, 1, 0, 9223372036854775807, 1)
                  _29 = torch.slice(_28, 2, 0, 9223372036854775807, 1)
                  _30 = torch.slice(_29, 3, 0, _7[-3], 1)
                  input3 = torch.cat([input1, _30], 3)
                  _31 = torch.slice(input3, 0, 0, 9223372036854775807, 1)
                  _32 = torch.slice(_31, 1, 0, 9223372036854775807, 1)
                  _33 = torch.add(_7[-3], _7[-4])
                  _34 = torch.slice(_32, 2, 0, 9223372036854775807, 1)
                  _35 = torch.slice(_34, 3, torch.neg(_33), torch.neg(_7[-3]), 1)
                  input2 = torch.cat([_35, input3], 3)
                else:
                  input2 = input1
                _36 = torch.gt(torch.len(_7), 4)
                if _36:
                  _37 = torch.slice(input2, 0, 0, 9223372036854775807, 1)
                  _38 = torch.slice(_37, 1, 0, 9223372036854775807, 1)
                  _39 = torch.slice(_38, 2, 0, 9223372036854775807, 1)
                  _40 = torch.slice(_39, 3, 0, 9223372036854775807, 1)
                  _41 = torch.slice(_40, 4, 0, _7[-5], 1)
                  input5 = torch.cat([input2, _41], 4)
                  _42 = torch.slice(input5, 0, 0, 9223372036854775807, 1)
                  _43 = torch.slice(_42, 1, 0, 9223372036854775807, 1)
                  _44 = torch.slice(_43, 2, 0, 9223372036854775807, 1)
                  _45 = torch.add(_7[-5], _7[-6])
                  _46 = torch.slice(_44, 3, 0, 9223372036854775807, 1)
                  _47 = torch.slice(_46, 4, torch.neg(_45), torch.neg(_7[-5]), 1)
                  input4 = torch.cat([_47, input5], 4)
                else:
                  input4 = input2
                _18 = input4
              else:
                ops.prim.RaiseException("Exception")
                _18 = _8
              _16 = _18
            _14 = _16
          _12 = _14
        else:
          if torch.eq(torch.dim(input), 4):
            if torch.eq(torch.len(_7), 4):
              pass
            else:
              ops.prim.RaiseException("Exception")
            _49 = torch.eq("circular", "reflect")
            if _49:
              _50 = torch.reflection_pad2d(input, _7)
            else:
              _51 = torch.eq("circular", "replicate")
              if _51:
                _52 = torch.replication_pad2d(input, _7)
              else:
                _53 = torch.eq("circular", "circular")
                if _53:
                  _55 = torch.slice(input, 0, 0, 9223372036854775807, 1)
                  _56 = torch.slice(_55, 1, 0, 9223372036854775807, 1)
                  _57 = torch.slice(_56, 2, 0, _7[-1], 1)
                  input6 = torch.cat([input, _57], 2)
                  _58 = torch.slice(input6, 0, 0, 9223372036854775807, 1)
                  _59 = torch.add(_7[-1], _7[-2])
                  _60 = torch.slice(_58, 1, 0, 9223372036854775807, 1)
                  _61 = torch.slice(_60, 2, torch.neg(_59), torch.neg(_7[-1]), 1)
                  input7 = torch.cat([_61, input6], 2)
                  _62 = torch.gt(torch.len(_7), 2)
                  if _62:
                    _63 = torch.slice(input7, 0, 0, 9223372036854775807, 1)
                    _64 = torch.slice(_63, 1, 0, 9223372036854775807, 1)
                    _65 = torch.slice(_64, 2, 0, 9223372036854775807, 1)
                    _66 = torch.slice(_65, 3, 0, _7[-3], 1)
                    input9 = torch.cat([input7, _66], 3)
                    _67 = torch.slice(input9, 0, 0, 9223372036854775807, 1)
                    _68 = torch.slice(_67, 1, 0, 9223372036854775807, 1)
                    _69 = torch.add(_7[-3], _7[-4])
                    _70 = torch.slice(_68, 2, 0, 9223372036854775807, 1)
                    _71 = torch.slice(_70, 3, torch.neg(_69), torch.neg(_7[-3]), 1)
                    input8 = torch.cat([_71, input9], 3)
                  else:
                    input8 = input7
                  _72 = torch.gt(torch.len(_7), 4)
                  if _72:
                    _73 = torch.slice(input8, 0, 0, 9223372036854775807, 1)
                    _74 = torch.slice(_73, 1, 0, 9223372036854775807, 1)
                    _75 = torch.slice(_74, 2, 0, 9223372036854775807, 1)
                    _76 = torch.slice(_75, 3, 0, 9223372036854775807, 1)
                    _77 = torch.slice(_76, 4, 0, _7[-5], 1)
                    input11 = torch.cat([input8, _77], 4)
                    _78 = torch.slice(input11, 0, 0, 9223372036854775807, 1)
                    _79 = torch.slice(_78, 1, 0, 9223372036854775807, 1)
                    _80 = torch.slice(_79, 2, 0, 9223372036854775807, 1)
                    _81 = torch.add(_7[-5], _7[-6])
                    _82 = torch.slice(_80, 3, 0, 9223372036854775807, 1)
                    _83 = torch.slice(_82, 4, torch.neg(_81), torch.neg(_7[-5]), 1)
                    input10 = torch.cat([_83, input11], 4)
                  else:
                    input10 = input8
                  _54 = input10
                else:
                  ops.prim.RaiseException("Exception")
                  _54 = _8
                _52 = _54
              _50 = _52
            _48 = _50
          else:
            _84 = torch.eq(torch.dim(input), 5)
            if _84:
              _86 = torch.eq(torch.len(_7), 6)
              if _86:
                pass
              else:
                ops.prim.RaiseException("Exception")
              _87 = torch.eq("circular", "reflect")
              if _87:
                ops.prim.RaiseException("Exception")
                _88 = _8
              else:
                _89 = torch.eq("circular", "replicate")
                if _89:
                  _90 = torch.replication_pad3d(input, _7)
                else:
                  _91 = torch.eq("circular", "circular")
                  if _91:
                    _93 = torch.slice(input, 0, 0, 9223372036854775807, 1)
                    _94 = torch.slice(_93, 1, 0, 9223372036854775807, 1)
                    _95 = torch.slice(_94, 2, 0, _7[-1], 1)
                    input12 = torch.cat([input, _95], 2)
                    _96 = torch.slice(input12, 0, 0, 9223372036854775807, 1)
                    _97 = torch.add(_7[-1], _7[-2])
                    _98 = torch.slice(_96, 1, 0, 9223372036854775807, 1)
                    _99 = torch.slice(_98, 2, torch.neg(_97), torch.neg(_7[-1]), 1)
                    input13 = torch.cat([_99, input12], 2)
                    _100 = torch.gt(torch.len(_7), 2)
                    if _100:
                      _101 = torch.slice(input13, 0, 0, 9223372036854775807, 1)
                      _102 = torch.slice(_101, 1, 0, 9223372036854775807, 1)
                      _103 = torch.slice(_102, 2, 0, 9223372036854775807, 1)
                      _104 = torch.slice(_103, 3, 0, _7[-3], 1)
                      input15 = torch.cat([input13, _104], 3)
                      _105 = torch.slice(input15, 0, 0, 9223372036854775807, 1)
                      _106 = torch.slice(_105, 1, 0, 9223372036854775807, 1)
                      _107 = torch.add(_7[-3], _7[-4])
                      _108 = torch.slice(_106, 2, 0, 9223372036854775807, 1)
                      _109 = torch.slice(_108, 3, torch.neg(_107), torch.neg(_7[-3]), 1)
                      input14 = torch.cat([_109, input15], 3)
                    else:
                      input14 = input13
                    _110 = torch.gt(torch.len(_7), 4)
                    if _110:
                      _111 = torch.slice(input14, 0, 0, 9223372036854775807, 1)
                      _112 = torch.slice(_111, 1, 0, 9223372036854775807, 1)
                      _113 = torch.slice(_112, 2, 0, 9223372036854775807, 1)
                      _114 = torch.slice(_113, 3, 0, 9223372036854775807, 1)
                      _115 = torch.slice(_114, 4, 0, _7[-5], 1)
                      input17 = torch.cat([input14, _115], 4)
                      _116 = torch.slice(input17, 0, 0, 9223372036854775807, 1)
                      _117 = torch.slice(_116, 1, 0, 9223372036854775807, 1)
                      _118 = torch.slice(_117, 2, 0, 9223372036854775807, 1)
                      _119 = torch.add(_7[-5], _7[-6])
                      _120 = torch.slice(_118, 3, 0, 9223372036854775807, 1)
                      _121 = torch.slice(_120, 4, torch.neg(_119), torch.neg(_7[-5]), 1)
                      input16 = torch.cat([_121, input17], 4)
                    else:
                      input16 = input14
                    _92 = input16
                  else:
                    ops.prim.RaiseException("Exception")
                    _92 = _8
                  _90 = _92
                _88 = _90
              _85 = _88
            else:
              ops.prim.RaiseException("Exception")
              _85 = _8
            _48 = _85
          _12 = _48
        _11 = _12
      _122 = self.bias
      _123 = [0, 0]
      _2, _3 = True, torch.conv2d(_11, _0, _122, [1, 1], _123, [1, 1], 1)
    else:
      _2, _3 = False, _1
    if _2:
      _124 = _3
    else:
      _124 = torch.conv2d(input, _0, self.bias, [1, 1], [0, 0], [1, 1], 1)
    return _124
  def conv2d_forward(self: __torch__.torch.nn.modules.conv.Conv2d,
    input: Tensor,
    weight: Tensor) -> Tensor:
    _125 = uninitialized(Tensor)
    if torch.eq("zeros", "circular"):
      _128 = torch.floordiv(torch.add(0, 1), 2)
      _129 = torch.floordiv(0, 2)
      _130 = torch.floordiv(torch.add(0, 1), 2)
      _131 = [_128, _129, _130, torch.floordiv(0, 2)]
      _132 = uninitialized(Tensor)
      _133 = torch.remainder(torch.len(_131), 2)
      if torch.eq(_133, 0):
        pass
      else:
        ops.prim.RaiseException("Exception")
      _134 = torch.floordiv(torch.len(_131), 2)
      if torch.le(_134, torch.dim(input)):
        pass
      else:
        ops.prim.RaiseException("Exception")
      if torch.eq("circular", "constant"):
        _135 = torch.constant_pad_nd(input, _131, 0.)
      else:
        if torch.eq(0., 0):
          pass
        else:
          ops.prim.RaiseException("Exception")
        if torch.eq(torch.dim(input), 3):
          if torch.eq(torch.len(_131), 2):
            pass
          else:
            ops.prim.RaiseException("Exception")
          _137 = torch.eq("circular", "reflect")
          if _137:
            _138 = torch.reflection_pad1d(input, _131)
          else:
            _139 = torch.eq("circular", "replicate")
            if _139:
              _140 = torch.replication_pad1d(input, _131)
            else:
              _141 = torch.eq("circular", "circular")
              if _141:
                _143 = torch.slice(input, 0, 0, 9223372036854775807, 1)
                _144 = torch.slice(_143, 1, 0, 9223372036854775807, 1)
                _145 = torch.slice(_144, 2, 0, _131[-1], 1)
                input18 = torch.cat([input, _145], 2)
                _146 = torch.slice(input18, 0, 0, 9223372036854775807, 1)
                _147 = torch.add(_131[-1], _131[-2])
                _148 = torch.slice(_146, 1, 0, 9223372036854775807, 1)
                _149 = torch.slice(_148, 2, torch.neg(_147), torch.neg(_131[-1]), 1)
                input19 = torch.cat([_149, input18], 2)
                _150 = torch.gt(torch.len(_131), 2)
                if _150:
                  _151 = torch.slice(input19, 0, 0, 9223372036854775807, 1)
                  _152 = torch.slice(_151, 1, 0, 9223372036854775807, 1)
                  _153 = torch.slice(_152, 2, 0, 9223372036854775807, 1)
                  _154 = torch.slice(_153, 3, 0, _131[-3], 1)
                  input21 = torch.cat([input19, _154], 3)
                  _155 = torch.slice(input21, 0, 0, 9223372036854775807, 1)
                  _156 = torch.slice(_155, 1, 0, 9223372036854775807, 1)
                  _157 = torch.add(_131[-3], _131[-4])
                  _158 = torch.slice(_156, 2, 0, 9223372036854775807, 1)
                  _159 = torch.slice(_158, 3, torch.neg(_157), torch.neg(_131[-3]), 1)
                  input20 = torch.cat([_159, input21], 3)
                else:
                  input20 = input19
                _160 = torch.gt(torch.len(_131), 4)
                if _160:
                  _161 = torch.slice(input20, 0, 0, 9223372036854775807, 1)
                  _162 = torch.slice(_161, 1, 0, 9223372036854775807, 1)
                  _163 = torch.slice(_162, 2, 0, 9223372036854775807, 1)
                  _164 = torch.slice(_163, 3, 0, 9223372036854775807, 1)
                  _165 = torch.slice(_164, 4, 0, _131[-5], 1)
                  input23 = torch.cat([input20, _165], 4)
                  _166 = torch.slice(input23, 0, 0, 9223372036854775807, 1)
                  _167 = torch.slice(_166, 1, 0, 9223372036854775807, 1)
                  _168 = torch.slice(_167, 2, 0, 9223372036854775807, 1)
                  _169 = torch.add(_131[-5], _131[-6])
                  _170 = torch.slice(_168, 3, 0, 9223372036854775807, 1)
                  _171 = torch.slice(_170, 4, torch.neg(_169), torch.neg(_131[-5]), 1)
                  input22 = torch.cat([_171, input23], 4)
                else:
                  input22 = input20
                _142 = input22
              else:
                ops.prim.RaiseException("Exception")
                _142 = _132
              _140 = _142
            _138 = _140
          _136 = _138
        else:
          if torch.eq(torch.dim(input), 4):
            _173 = torch.eq(torch.len(_131), 4)
            if _173:
              pass
            else:
              ops.prim.RaiseException("Exception")
            _174 = torch.eq("circular", "reflect")
            if _174:
              _175 = torch.reflection_pad2d(input, _131)
            else:
              _176 = torch.eq("circular", "replicate")
              if _176:
                _177 = torch.replication_pad2d(input, _131)
              else:
                _178 = torch.eq("circular", "circular")
                if _178:
                  _180 = torch.slice(input, 0, 0, 9223372036854775807, 1)
                  _181 = torch.slice(_180, 1, 0, 9223372036854775807, 1)
                  _182 = torch.slice(_181, 2, 0, _131[-1], 1)
                  input24 = torch.cat([input, _182], 2)
                  _183 = torch.slice(input24, 0, 0, 9223372036854775807, 1)
                  _184 = torch.add(_131[-1], _131[-2])
                  _185 = torch.slice(_183, 1, 0, 9223372036854775807, 1)
                  _186 = torch.slice(_185, 2, torch.neg(_184), torch.neg(_131[-1]), 1)
                  input25 = torch.cat([_186, input24], 2)
                  _187 = torch.gt(torch.len(_131), 2)
                  if _187:
                    _188 = torch.slice(input25, 0, 0, 9223372036854775807, 1)
                    _189 = torch.slice(_188, 1, 0, 9223372036854775807, 1)
                    _190 = torch.slice(_189, 2, 0, 9223372036854775807, 1)
                    _191 = torch.slice(_190, 3, 0, _131[-3], 1)
                    input27 = torch.cat([input25, _191], 3)
                    _192 = torch.slice(input27, 0, 0, 9223372036854775807, 1)
                    _193 = torch.slice(_192, 1, 0, 9223372036854775807, 1)
                    _194 = torch.add(_131[-3], _131[-4])
                    _195 = torch.slice(_193, 2, 0, 9223372036854775807, 1)
                    _196 = torch.slice(_195, 3, torch.neg(_194), torch.neg(_131[-3]), 1)
                    input26 = torch.cat([_196, input27], 3)
                  else:
                    input26 = input25
                  _197 = torch.gt(torch.len(_131), 4)
                  if _197:
                    _198 = torch.slice(input26, 0, 0, 9223372036854775807, 1)
                    _199 = torch.slice(_198, 1, 0, 9223372036854775807, 1)
                    _200 = torch.slice(_199, 2, 0, 9223372036854775807, 1)
                    _201 = torch.slice(_200, 3, 0, 9223372036854775807, 1)
                    _202 = torch.slice(_201, 4, 0, _131[-5], 1)
                    input29 = torch.cat([input26, _202], 4)
                    _203 = torch.slice(input29, 0, 0, 9223372036854775807, 1)
                    _204 = torch.slice(_203, 1, 0, 9223372036854775807, 1)
                    _205 = torch.slice(_204, 2, 0, 9223372036854775807, 1)
                    _206 = torch.add(_131[-5], _131[-6])
                    _207 = torch.slice(_205, 3, 0, 9223372036854775807, 1)
                    _208 = torch.slice(_207, 4, torch.neg(_206), torch.neg(_131[-5]), 1)
                    input28 = torch.cat([_208, input29], 4)
                  else:
                    input28 = input26
                  _179 = input28
                else:
                  ops.prim.RaiseException("Exception")
                  _179 = _132
                _177 = _179
              _175 = _177
            _172 = _175
          else:
            _209 = torch.eq(torch.dim(input), 5)
            if _209:
              _211 = torch.eq(torch.len(_131), 6)
              if _211:
                pass
              else:
                ops.prim.RaiseException("Exception")
              _212 = torch.eq("circular", "reflect")
              if _212:
                ops.prim.RaiseException("Exception")
                _213 = _132
              else:
                _214 = torch.eq("circular", "replicate")
                if _214:
                  _215 = torch.replication_pad3d(input, _131)
                else:
                  _216 = torch.eq("circular", "circular")
                  if _216:
                    _218 = torch.slice(input, 0, 0, 9223372036854775807, 1)
                    _219 = torch.slice(_218, 1, 0, 9223372036854775807, 1)
                    _220 = torch.slice(_219, 2, 0, _131[-1], 1)
                    input30 = torch.cat([input, _220], 2)
                    _221 = torch.slice(input30, 0, 0, 9223372036854775807, 1)
                    _222 = torch.add(_131[-1], _131[-2])
                    _223 = torch.slice(_221, 1, 0, 9223372036854775807, 1)
                    _224 = torch.slice(_223, 2, torch.neg(_222), torch.neg(_131[-1]), 1)
                    input31 = torch.cat([_224, input30], 2)
                    _225 = torch.gt(torch.len(_131), 2)
                    if _225:
                      _226 = torch.slice(input31, 0, 0, 9223372036854775807, 1)
                      _227 = torch.slice(_226, 1, 0, 9223372036854775807, 1)
                      _228 = torch.slice(_227, 2, 0, 9223372036854775807, 1)
                      _229 = torch.slice(_228, 3, 0, _131[-3], 1)
                      input33 = torch.cat([input31, _229], 3)
                      _230 = torch.slice(input33, 0, 0, 9223372036854775807, 1)
                      _231 = torch.slice(_230, 1, 0, 9223372036854775807, 1)
                      _232 = torch.add(_131[-3], _131[-4])
                      _233 = torch.slice(_231, 2, 0, 9223372036854775807, 1)
                      _234 = torch.neg(_232)
                      _235 = torch.neg(_131[-3])
                      _236 = torch.slice(_233, 3, _234, _235, 1)
                      input32 = torch.cat([_236, input33], 3)
                    else:
                      input32 = input31
                    _237 = torch.gt(torch.len(_131), 4)
                    if _237:
                      _238 = torch.slice(input32, 0, 0, 9223372036854775807, 1)
                      _239 = torch.slice(_238, 1, 0, 9223372036854775807, 1)
                      _240 = torch.slice(_239, 2, 0, 9223372036854775807, 1)
                      _241 = torch.slice(_240, 3, 0, 9223372036854775807, 1)
                      _242 = torch.slice(_241, 4, 0, _131[-5], 1)
                      input35 = torch.cat([input32, _242], 4)
                      _243 = torch.slice(input35, 0, 0, 9223372036854775807, 1)
                      _244 = torch.slice(_243, 1, 0, 9223372036854775807, 1)
                      _245 = torch.slice(_244, 2, 0, 9223372036854775807, 1)
                      _246 = torch.add(_131[-5], _131[-6])
                      _247 = torch.slice(_245, 3, 0, 9223372036854775807, 1)
                      _248 = torch.neg(_246)
                      _249 = torch.neg(_131[-5])
                      _250 = torch.slice(_247, 4, _248, _249, 1)
                      input34 = torch.cat([_250, input35], 4)
                    else:
                      input34 = input32
                    _217 = input34
                  else:
                    ops.prim.RaiseException("Exception")
                    _217 = _132
                  _215 = _217
                _213 = _215
              _210 = _213
            else:
              ops.prim.RaiseException("Exception")
              _210 = _132
            _172 = _210
          _136 = _172
        _135 = _136
      _251 = self.bias
      _252 = [0, 0]
      _126, _127 = True, torch.conv2d(_135, weight, _251, [1, 1], _252, [1, 1], 1)
    else:
      _126, _127 = False, _125
    if _126:
      _253 = _127
    else:
      _253 = torch.conv2d(input, weight, self.bias, [1, 1], [0, 0], [1, 1], 1)
    return _253
class ConvTranspose2d(Module):
  __parameters__ = ["bias", "weight", ]
  training : bool
  bias : Tensor
  weight : Tensor
  __constants__ : List[str]
  transposed : bool
  def forward(self: __torch__.torch.nn.modules.conv.ConvTranspose2d,
    input: Tensor,
    output_size: Optional[List[int]]=None) -> Tensor:
    if torch.ne("zeros", "zeros"):
      ops.prim.RaiseException("Exception")
    else:
      pass
    _0 = [2, 2]
    _1 = [0, 0]
    _2 = [3, 3]
    if torch.__is__(output_size, None):
      output_padding = [0, 0]
    else:
      output_size0 = ops.prim.unchecked_unwrap_optional(output_size)
      k = torch.sub(torch.dim(input), 2)
      _3 = torch.eq(torch.len(output_size0), torch.add(k, 2))
      if _3:
        output_size1 = torch.slice(output_size0, 2, 9223372036854775807, 1)
      else:
        output_size1 = output_size0
      _4 = torch.ne(torch.len(output_size1), k)
      if _4:
        ops.prim.RaiseException("Exception")
      else:
        pass
      min_sizes = annotate(List[int], [])
      max_sizes = annotate(List[int], [])
      for d in range(k):
        _5 = torch.size(input, torch.add(d, 2))
        _6 = torch.mul(torch.sub(_5, 1), _0[d])
        _7 = torch.sub(_6, torch.mul(2, _1[d]))
        dim_size = torch.add(_7, _2[d])
        _8 = torch.append(min_sizes, dim_size)
        _9 = torch.sub(torch.add(min_sizes[d], _0[d]), 1)
        _10 = torch.append(max_sizes, _9)
      for i in range(torch.len(output_size1)):
        size = output_size1[i]
        min_size = min_sizes[i]
        max_size = max_sizes[i]
        if torch.lt(size, min_size):
          _11 = True
        else:
          _11 = torch.gt(size, max_size)
        if _11:
          ops.prim.RaiseException("Exception")
        else:
          pass
      res = annotate(List[int], [])
      for d0 in range(k):
        _12 = torch.sub(output_size1[d0], min_sizes[d0])
        _13 = torch.append(res, _12)
      output_padding = res
    _14 = torch.conv_transpose2d(input, self.weight, self.bias, [2, 2], [0, 0], output_padding, 1, [1, 1])
    return _14
  def _output_padding(self: __torch__.torch.nn.modules.conv.ConvTranspose2d,
    input: Tensor,
    output_size: Optional[List[int]],
    stride: List[int],
    padding: List[int],
    kernel_size: List[int]) -> List[int]:
    if torch.__is__(output_size, None):
      ret = [0, 0]
    else:
      output_size2 = ops.prim.unchecked_unwrap_optional(output_size)
      k = torch.sub(torch.dim(input), 2)
      _15 = torch.eq(torch.len(output_size2), torch.add(k, 2))
      if _15:
        output_size3 = torch.slice(output_size2, 2, 9223372036854775807, 1)
      else:
        output_size3 = output_size2
      _16 = torch.ne(torch.len(output_size3), k)
      if _16:
        ops.prim.RaiseException("Exception")
      else:
        pass
      min_sizes = annotate(List[int], [])
      max_sizes = annotate(List[int], [])
      for d in range(k):
        _17 = torch.size(input, torch.add(d, 2))
        _18 = torch.mul(torch.sub(_17, 1), stride[d])
        _19 = torch.sub(_18, torch.mul(2, padding[d]))
        dim_size = torch.add(_19, kernel_size[d])
        _20 = torch.append(min_sizes, dim_size)
        _21 = torch.add(min_sizes[d], stride[d])
        _22 = torch.append(max_sizes, torch.sub(_21, 1))
      for i in range(torch.len(output_size3)):
        size = output_size3[i]
        min_size = min_sizes[i]
        max_size = max_sizes[i]
        if torch.lt(size, min_size):
          _23 = True
        else:
          _23 = torch.gt(size, max_size)
        if _23:
          ops.prim.RaiseException("Exception")
        else:
          pass
      res = annotate(List[int], [])
      for d1 in range(k):
        _24 = torch.sub(output_size3[d1], min_sizes[d1])
        _25 = torch.append(res, _24)
      ret = res
    return ret
