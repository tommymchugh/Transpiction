op_version_set = 1
class ConvTranspose2d(Module):
  __parameters__ = ["bias", "weight", ]
  training : bool
  bias : Tensor
  weight : Tensor
  __constants__ : List[str]
  transposed : bool
  def forward(self: __torch__.torch.nn.modules.conv.___torch_mangle_24.ConvTranspose2d,
    input: Tensor,
    output_size: Optional[List[int]]=None) -> Tensor:
    if torch.ne("zeros", "zeros"):
      ops.prim.RaiseException("Exception")
    else:
      pass
    _0 = [2, 2]
    _1 = [0, 0]
    _2 = [3, 3]
    if torch.__is__(output_size, None):
      output_padding = [1, 1]
    else:
      output_size0 = ops.prim.unchecked_unwrap_optional(output_size)
      k = torch.sub(torch.dim(input), 2)
      _3 = torch.eq(torch.len(output_size0), torch.add(k, 2))
      if _3:
        output_size1 = torch.slice(output_size0, 2, 9223372036854775807, 1)
      else:
        output_size1 = output_size0
      _4 = torch.ne(torch.len(output_size1), k)
      if _4:
        ops.prim.RaiseException("Exception")
      else:
        pass
      min_sizes = annotate(List[int], [])
      max_sizes = annotate(List[int], [])
      for d in range(k):
        _5 = torch.size(input, torch.add(d, 2))
        _6 = torch.mul(torch.sub(_5, 1), _0[d])
        _7 = torch.sub(_6, torch.mul(2, _1[d]))
        dim_size = torch.add(_7, _2[d])
        _8 = torch.append(min_sizes, dim_size)
        _9 = torch.sub(torch.add(min_sizes[d], _0[d]), 1)
        _10 = torch.append(max_sizes, _9)
      for i in range(torch.len(output_size1)):
        size = output_size1[i]
        min_size = min_sizes[i]
        max_size = max_sizes[i]
        if torch.lt(size, min_size):
          _11 = True
        else:
          _11 = torch.gt(size, max_size)
        if _11:
          ops.prim.RaiseException("Exception")
        else:
          pass
      res = annotate(List[int], [])
      for d0 in range(k):
        _12 = torch.sub(output_size1[d0], min_sizes[d0])
        _13 = torch.append(res, _12)
      output_padding = res
    _14 = torch.conv_transpose2d(input, self.weight, self.bias, [2, 2], [0, 0], output_padding, 1, [1, 1])
    return _14
  def _output_padding(self: __torch__.torch.nn.modules.conv.___torch_mangle_24.ConvTranspose2d,
    input: Tensor,
    output_size: Optional[List[int]],
    stride: List[int],
    padding: List[int],
    kernel_size: List[int]) -> List[int]:
    if torch.__is__(output_size, None):
      ret = [1, 1]
    else:
      output_size2 = ops.prim.unchecked_unwrap_optional(output_size)
      k = torch.sub(torch.dim(input), 2)
      _15 = torch.eq(torch.len(output_size2), torch.add(k, 2))
      if _15:
        output_size3 = torch.slice(output_size2, 2, 9223372036854775807, 1)
      else:
        output_size3 = output_size2
      _16 = torch.ne(torch.len(output_size3), k)
      if _16:
        ops.prim.RaiseException("Exception")
      else:
        pass
      min_sizes = annotate(List[int], [])
      max_sizes = annotate(List[int], [])
      for d in range(k):
        _17 = torch.size(input, torch.add(d, 2))
        _18 = torch.mul(torch.sub(_17, 1), stride[d])
        _19 = torch.sub(_18, torch.mul(2, padding[d]))
        dim_size = torch.add(_19, kernel_size[d])
        _20 = torch.append(min_sizes, dim_size)
        _21 = torch.add(min_sizes[d], stride[d])
        _22 = torch.append(max_sizes, torch.sub(_21, 1))
      for i in range(torch.len(output_size3)):
        size = output_size3[i]
        min_size = min_sizes[i]
        max_size = max_sizes[i]
        if torch.lt(size, min_size):
          _23 = True
        else:
          _23 = torch.gt(size, max_size)
        if _23:
          ops.prim.RaiseException("Exception")
        else:
          pass
      res = annotate(List[int], [])
      for d1 in range(k):
        _24 = torch.sub(output_size3[d1], min_sizes[d1])
        _25 = torch.append(res, _24)
      ret = res
    return ret
