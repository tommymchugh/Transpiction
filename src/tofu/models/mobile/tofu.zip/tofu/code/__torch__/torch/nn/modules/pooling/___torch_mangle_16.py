op_version_set = 1
class MaxPool2d(Module):
  __parameters__ = []
  training : bool
  __constants__ : List[str]
  def forward(self: __torch__.torch.nn.modules.pooling.___torch_mangle_16.MaxPool2d,
    input: Tensor) -> Tensor:
    _0 = [2, 2]
    _1 = [2, 2]
    _2 = [0, 0]
    _3 = [1, 1]
    if torch.__is__(_1, None):
      stride = annotate(List[int], [])
    else:
      stride = ops.prim.unchecked_unwrap_optional(_1)
    _4 = torch.max_pool2d(input, _0, stride, _2, _3, False)
    return _4
