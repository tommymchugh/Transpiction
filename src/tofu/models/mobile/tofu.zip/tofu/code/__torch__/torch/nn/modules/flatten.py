op_version_set = 1
class Flatten(Module):
  __parameters__ = []
  training : bool
  __constants__ : List[str]
  def forward(self: __torch__.torch.nn.modules.flatten.Flatten,
    input: Tensor) -> Tensor:
    return torch.flatten(input, 1, -1)
